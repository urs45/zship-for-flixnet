
# 2022-10-09
# edit 2026-09-12.8

import sys, os, requests, threading, time, re, html, shutil
from random import choice

is_python2 = sys.version_info.major == 2
if is_python2:
    from xbmc import translatePath
    from urlparse import urlparse
else:
    from xbmcvfs import translatePath
    from urllib.parse import urlparse

# Settings guard: repair malformed profile settings before xbmcaddon.Addon()
# tries to load them. Previous builds wrote settings concurrently from many
# domain-check threads, which can leave settings.xml truncated on Android.
_SETTINGS_REPAIR_NOTE = ''
_PROFILE_SETTINGS = translatePath(
    'special://profile/addon_data/plugin.video.zship/settings.xml'
)

def _repair_profile_settings():
    global _SETTINGS_REPAIR_NOTE
    path = _PROFILE_SETTINGS
    if not path or not os.path.exists(path):
        return

    raw = ''
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as fh:
            raw = fh.read()
        ET = __import__('xml.etree.ElementTree', fromlist=['ElementTree'])
        root = ET.fromstring(raw)
        if root.tag == 'settings':
            ids = []
            for node in root.findall('setting'):
                sid = node.attrib.get('id')
                if sid:
                    ids.append(sid)
            if len(ids) == len(set(ids)):
                return
    except Exception:
        pass

    stamp = time.strftime('%Y%m%d-%H%M%S')
    backup = path + '.corrupt-' + stamp + '.bak'
    try:
        shutil.copy2(path, backup)
    except Exception:
        backup = ''

    salvaged = {}
    try:
        pattern = re.compile(
            r"<setting\b[^>]*\bid=([\"'])(.*?)\1[^>]*>(.*?)</setting\s*>",
            re.I | re.S
        )
        for m in pattern.finditer(raw):
            sid = m.group(2).strip()
            value = re.sub(r'<[^>]+>', '', m.group(3))
            value = html.unescape(value).strip()
            if sid:
                salvaged[sid] = value
    except Exception:
        salvaged = {}

    try:
        ET = __import__('xml.etree.ElementTree', fromlist=['ElementTree'])
        root = ET.Element('settings', {'version': '2'})
        for sid in sorted(salvaged):
            node = ET.SubElement(root, 'setting', {'id': sid})
            node.text = salvaged[sid]

        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.repair.tmp'
        ET.ElementTree(root).write(
            tmp, encoding='utf-8', xml_declaration=True
        )
        os.replace(tmp, path)
        _SETTINGS_REPAIR_NOTE = (
            '[settings-guard] settings.xml repariert: %d Werte gerettet%s'
            % (
                len(salvaged),
                ('; Backup=' + backup) if backup else ''
            )
        )
    except Exception as exc:
        try:
            if os.path.exists(path):
                if backup:
                    os.remove(path)
                else:
                    os.replace(path, path + '.corrupt-' + stamp)
            _SETTINGS_REPAIR_NOTE = (
                '[settings-guard] defekte settings.xml entfernt; '
                'Kodi verwendet Standardwerte. Fehler=' + str(exc)
            )
        except Exception:
            pass

_repair_profile_settings()

from xbmcaddon import Addon

try:
    from resources.lib.tools import logger
    isLogger = True
except Exception:
    isLogger = False

_ADDON = Addon()
addonInfo = _ADDON.getAddonInfo
addonPath = translatePath(addonInfo('path'))
addonVersion = addonInfo('version')

_SETTINGS_LOCK = threading.RLock()

def getSetting(Name, default=''):
    try:
        with _SETTINGS_LOCK:
            result = _ADDON.getSetting(Name)
        return result if result else default
    except Exception:
        return default

def setSetting(Name, value):
    value = '' if value is None else str(value)
    try:
        with _SETTINGS_LOCK:
            current = _ADDON.getSetting(Name)
            if current == value:
                return True
            _ADDON.setSetting(Name, value)
        return True
    except Exception as exc:
        if isLogger:
            try:
                logger.warning(
                    '[settings-guard] setSetting fehlgeschlagen: %s=%s | %s'
                    % (Name, value, str(exc))
                )
            except Exception:
                pass
        return False

if _SETTINGS_REPAIR_NOTE and isLogger:
    try:
        logger.warning(_SETTINGS_REPAIR_NOTE)
    except Exception:
        pass

# Html Cache beim KodiStart loeschen
def delHtmlCache():
    try:
        from resources.lib.requestHandler import cRequestHandler
        from time import time
        deltaDay = int(getSetting('cacheDeltaDay', 3))
        deltaTime = 60*60*24*deltaDay # Tage
        currentTime = int(time())
        # einmalig
        if getSetting('delHtmlCache') == 'true':
            cRequestHandler('').clearCache()
            setSetting('lastdelhtml', str(currentTime))
            setSetting('delHtmlCache', 'false')
        # alle x Tage
        elif currentTime >= int(getSetting('lastdelhtml', 0)) + deltaTime:
            cRequestHandler('').clearCache()
            setSetting('lastdelhtml', str(currentTime))
    except: pass

# Scraper(Seiten) ein- / ausschalten
#  [(providername, domainname), ...]     providername identisch mit dateiname
def _getPluginData():
    import importlib.util
    from os import path
    from scrapers import getActiveProviderFolder, getProviderModuleNames
    sPluginFolder = getActiveProviderFolder()
    if sPluginFolder not in sys.path:
        sys.path.append(sPluginFolder)
    aFileNames = getProviderModuleNames()
    aPluginsData = []
    for fileName in aFileNames:
        try:
            module_path = path.join(sPluginFolder, fileName + '.py')
            spec = importlib.util.spec_from_file_location('zship_service_%s' % fileName, module_path)
            plugin = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(plugin)
            # print(plugin.SITE_DOMAIN +'  '+ plugin.SITE_IDENTIFIER)
            aPluginsData.append({'domain': plugin.SITE_DOMAIN, 'provider': plugin.SITE_IDENTIFIER})
        except:
            pass
    return aPluginsData


def check_domains():
    domains = _getPluginData()
    import threading
    threads = []
    try:
        for item in domains:
            _domain = item['domain']
            _provider = item['provider']
            t = threading.Thread(target=_checkdomain, args=(_domain, _provider))
            threads += [t]
            t.start()
    except:
        pass
    for count, t in enumerate(threads):
        t.join()

def RandomUA():
    #Random User Agents aktualisiert 08.06.2025
    FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0'
    OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 OPR/119.0.0.0'
    ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 15; SM-S931U Build/AP3A.240905.015.A2; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/132.0.6834.163 Mobile Safari/537.36'
    EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'
    CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36'
    SAFARI_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15'

    _User_Agents = [FF_USER_AGENT, OPERA_USER_AGENT, EDGE_USER_AGENT, CHROME_USER_AGENT, SAFARI_USER_AGENT]
    return choice(_User_Agents)

_XSHIP_PORTED_PROVIDERS = {
    'aniworld',
    'burningseries',
    'einschalten',
    'filmo',
    'filmpalast',
    'hdfilme',
    'huhu',
    'kinoger',
    'kinofun',
    'kinoking',
    'kinokiste',
    'kkiste',
    'kool',
    'megakino',
    'meinecloud',
    'moflix',
    'movie2k',
    'netzkino',
    'serienstream',
    'streamcloud',
    'topstreamfilm',
    'vavoo',
}



_XSHIP_PORT_BUILD = '2026.09.07.2'

def reset_xship_provider_state():
    try:
        if getSetting('xship.port.build', '') == _XSHIP_PORT_BUILD:
            return
        for _provider in _XSHIP_PORTED_PROVIDERS:
            setSetting('provider.' + _provider + '.domain', '')
            setSetting('provider.' + _provider + '.check', 'true')
            setSetting('provider.' + _provider + '.health', 'ok')
        setSetting('xship.port.build', _XSHIP_PORT_BUILD)
    except Exception:
        pass


def normalize_provider_domain_setting(_provider):
    try:
        key = 'provider.' + _provider + '.domain'
        raw = getSetting(key, '')
        if not raw:
            return
        value = str(raw).strip()
        if '://' not in value:
            value = 'https://' + value
        host = urlparse(value).hostname
        if host and host != raw:
            setSetting(key, host)
            if isLogger:
                logger.info(
                    '[settings-guard] Domain normalisiert: %s -> %s'
                    % (_provider, host)
                )
    except Exception:
        pass

_WRONG_DOMAINS = {
    'site-maps.cc',
    'www.site-maps.cc',
    'drei.at',
    'www.drei.at',
    'notice.cuii.info',
}

def _clean_domain(value):
    """Return a plain hostname from a setting/SITE_DOMAIN value."""
    try:
        raw = str(value or '').strip()
        if not raw:
            return ''
        if '://' not in raw:
            raw = 'https://' + raw
        return (urlparse(raw).hostname or '').strip().lower()
    except Exception:
        return ''

def _get_final_domain(start_domain, timeout=(5, 8)):
    """
    GET-based redirect/domain resolver.

    requests follows HTTP redirects automatically. stream=True means we only
    need response headers and don't download a complete landing page. This is
    deliberately GET rather than HEAD because many xShip/MovieScout-style
    index sites reject HEAD with 403/405 even though normal GET works.
    """
    domain = _clean_domain(start_domain)
    if not domain:
        return None, None, None

    base_link = 'https://' + domain
    headers = {
        'User-Agent': RandomUA(),
        'Referer': base_link + '/',
        'Accept': (
            'text/html,application/xhtml+xml,application/xml;q=0.9,'
            'image/avif,image/webp,*/*;q=0.8'
        ),
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.7',
        'Connection': 'close',
        'Upgrade-Insecure-Requests': '1',
    }

    response = None
    try:
        response = requests.get(
            base_link,
            verify=False,
            headers=headers,
            timeout=timeout,
            allow_redirects=True,
            stream=True
        )
        status = int(response.status_code)
        final_url = str(response.url or base_link)
        final_domain = _clean_domain(final_url)

        # Only a normal HTTP success/redirect chain is authoritative enough to
        # overwrite the user's saved domain. 401/403/429/5xx leave it untouched.
        if 200 <= status < 400 and final_domain:
            if final_domain in _WRONG_DOMAINS:
                return None, status, final_url
            return final_domain, status, final_url

        return None, status, final_url
    except Exception as exc:
        if isLogger:
            try:
                logger.info(
                    ' -> [service]: Domain-GET fehlgeschlagen: %s / %s'
                    % (domain, str(exc))
                )
            except Exception:
                pass
        return None, None, None
    finally:
        try:
            if response is not None:
                response.close()
        except Exception:
            pass

def _checkdomain(_domain, _provider):
    try:
        normalize_provider_domain_setting(_provider)
        requests.packages.urllib3.disable_warnings()

        shipped_domain = _clean_domain(_domain)
        setting_key = 'provider.' + _provider + '.domain'
        check_key = 'provider.' + _provider + '.check'

        saved_domain = _clean_domain(getSetting(setting_key, ''))
        current_domain = saved_domain or shipped_domain

        # Known stale values from older zShip builds. They are only start
        # candidates; the GET resolver below determines the final hostname.
        stale_domains = {
            'megakino': {'megakino16.com'},
            'topstreamfilm': {'topstreamfilm.best'},
            'streamcloud': {'streamcloud.my', 'streamcloud.plus'},
        }
        if current_domain in stale_domains.get(_provider, set()):
            current_domain = shipped_domain

        if _provider in _XSHIP_PORTED_PROVIDERS:
            # Important difference to 12.7:
            # Ported providers are no longer just "kept enabled". At startup
            # we now follow a REAL GET redirect and persist its final hostname,
            # exactly so provider files only need a fallback SITE_DOMAIN.
            candidates = []
            for candidate in (current_domain, shipped_domain):
                candidate = _clean_domain(candidate)
                if candidate and candidate not in candidates:
                    candidates.append(candidate)

            resolved_domain = None
            status_code = None
            final_url = None
            used_candidate = None

            for candidate in candidates:
                resolved, status, final = _get_final_domain(candidate)
                if status_code is None and status is not None:
                    status_code = status
                if resolved:
                    resolved_domain = resolved
                    status_code = status
                    final_url = final
                    used_candidate = candidate
                    break

            if resolved_domain:
                # Update only on a verified successful GET. This prevents a
                # transient outage/Cloudflare block from poisoning a working
                # saved domain.
                setSetting(setting_key, resolved_domain)
                setSetting(check_key, 'true')
                setSetting('provider.' + _provider + '.health', 'ok')

                if isLogger:
                    changed = (
                        saved_domain and
                        resolved_domain != saved_domain
                    )
                    logger.info(
                        ' -> [service]: Provider: %s / GET %s / '
                        'Domain: %s%s / URL: %s'
                        % (
                            _provider,
                            status_code,
                            resolved_domain,
                            ' [AKTUALISIERT von %s]' % saved_domain
                            if changed else '',
                            final_url or ''
                        )
                    )
            else:
                # Ported providers must remain searchable even when their home
                # page rejects the startup probe. Keep the last known domain.
                fallback = saved_domain or current_domain or shipped_domain
                if fallback and fallback not in _WRONG_DOMAINS:
                    setSetting(setting_key, fallback)
                setSetting(check_key, 'true')
                setSetting(
                    'provider.' + _provider + '.health',
                    'probe_failed'
                )

                if isLogger:
                    logger.info(
                        ' -> [service]: Provider: %s / GET %s / '
                        'Domainprobe fehlgeschlagen, behalte: %s'
                        % (_provider, status_code, fallback)
                    )
            return

        # Legacy/non-ported providers retain the previous behavior, but the
        # redirect resolver itself is now GET-based as well.
        resolved_domain, status_code, final_url = _get_final_domain(
            current_domain
        )

        if resolved_domain:
            setSetting(check_key, 'true')
            setSetting(setting_key, resolved_domain)
            if isLogger:
                logger.info(
                    ' -> [service]: Provider: %s / GET %s / '
                    'Domain: %s / URL: %s'
                    % (
                        _provider,
                        status_code,
                        resolved_domain,
                        final_url or ''
                    )
                )
        else:
            domain = current_domain
            if domain in _WRONG_DOMAINS:
                setSetting(check_key, '')
                setSetting(setting_key, '')
            else:
                setSetting(check_key, 'false')
                # Never overwrite a saved domain with an empty/failed result.
                if domain:
                    setSetting(setting_key, domain)

            if isLogger:
                logger.info(
                    ' -> [service]: Provider: %s / GET %s / '
                    'Domainprobe fehlgeschlagen: %s'
                    % (_provider, status_code, domain)
                )
    except Exception as exc:
        if isLogger:
            try:
                logger.warning(
                    ' -> [service]: Provider-Domaincheck Fehler %s: %s'
                    % (_provider, str(exc))
                )
            except Exception:
                pass

def ensure_youtube_api_keys():
    """Write bundled YouTube API keys to api_keys.json if not already configured.
    Only writes if no user key exists — never overwrites an existing configured key."""
    import json, base64
    try:
        yt_keys_path = translatePath('special://home/userdata/addon_data/plugin.video.youtube/api_keys.json')

        # If file exists, check whether a user key is already present
        if os.path.exists(yt_keys_path):
            try:
                with open(yt_keys_path, 'r') as f:
                    existing = json.load(f)
                if existing.get('keys', {}).get('user', {}).get('api_key', ''):
                    return  # user key already configured — do not touch
            except Exception:
                pass  # unreadable — fall through and write fresh

        # Write bundled fallback keys to api_keys.json.
        # JSON structure is visible as-is; values prefixed 'b64:' are decoded before writing.
        _template = """{
    "keys": {
        "user": {
            "api_key":       "b64:QUl6YVN5RG5sSjBlX0NabExvWm03Q01Obk80MXhJblpnVkZ5T2Jv",
            "client_id":     "b64:ODY5OTIyMDgxNzY5LWQzOTJkdTN2dTZjOGNwbXRsbDExcnBkN2YwOWRldTFuLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29t",
            "client_secret": "b64:R09DU1BYLVpPSWYwSnM3cUFCN3FsTWNvRkFDTlpqVWhfQ2o="
        },
        "developer": {}
    }
}"""

        def _resolve(obj):
            if isinstance(obj, dict):
                return {k: _resolve(v) for k, v in obj.items()}
            if isinstance(obj, str) and obj.startswith('b64:'):
                return base64.b64decode(obj[4:].encode()).decode()
            return obj

        yt_dir = os.path.dirname(yt_keys_path)
        if not os.path.exists(yt_dir):
            os.makedirs(yt_dir)

        with open(yt_keys_path, 'w') as f:
            json.dump(_resolve(json.loads(_template)), f, indent=4)
        if isLogger:
            logger.info('[service]: YouTube api_keys.json written')
    except Exception as e:
        if isLogger:
            logger.warning('[service]: Failed to write YouTube api_keys.json: %s' % str(e))


if __name__ == "__main__":
	import xbmc
	if not xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
		xbmc.executebuiltin('InstallAddon(inputstream.adaptive)')
		xbmc.executebuiltin('SendClick(11)')
	try:
		from resources.lib import hotfix, update_channel
		hotfix.bootstrap()
		update_channel.check_addon_update(force=True, notify=True)
	except Exception as _hotfix_exc:
		if isLogger:
			logger.warning('[SelfHeal] bootstrap/update failed: %s' % str(_hotfix_exc))
	reset_xship_provider_state()
	check_domains()
	delHtmlCache()
	ensure_youtube_api_keys()

	# Keep the service alive with a tiny five-minute heartbeat. The individual
	# remote functions enforce their own 30 min / 6 h intervals, so this adds
	# no request spam but lets long-running Kodi boxes receive rule updates
	# without a restart.
	try:
		_monitor = xbmc.Monitor()
		while not _monitor.abortRequested():
			if _monitor.waitForAbort(300):
				break
			try:
				hotfix.maybe_refresh_remote(force=False)
				update_channel.check_addon_update(force=False, notify=True)
			except Exception as _loop_exc:
				if isLogger:
					logger.info('[SelfHeal] background check skipped: %s' % str(_loop_exc))
	except Exception:
		pass
