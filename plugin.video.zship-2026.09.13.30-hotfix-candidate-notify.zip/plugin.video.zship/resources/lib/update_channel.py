# -*- coding: UTF-8 -*-
"""zShip public GitHub update channel.

The channel deliberately keeps executable code and remote data separate.
GitHub only supplies JSON metadata and declarative hotfix rules.  A remote
manifest can announce a newer add-on version, but zShip does not install code
from it automatically.
"""
import json
import os
import re
import time
from urllib.parse import quote
from urllib.request import Request, build_opener

from resources.lib import control, log_utils

_STATE = os.path.join(control.addonProfilePath, 'update_channel_state.json')
_MANIFEST_PROFILE = os.path.join(control.addonProfilePath, 'update_manifest.json')
_MAX_JSON = 256 * 1024

# Public read-only channel. These are NOT credentials: the repository is
# intentionally public and zShip never receives a GitHub token/password.
_GITHUB_OWNER = 'urs45'
_GITHUB_REPO = 'zship-for-flixnet'
_GITHUB_BRANCH = 'main'
_GITHUB_HOTFIX_PATH = 'hotfix_rules.json'
_GITHUB_MANIFEST_PATH = 'update_manifest.json'
_GITHUB_RAW_BASE = 'https://raw.githubusercontent.com/%s/%s/%s/' % (
    _GITHUB_OWNER, _GITHUB_REPO, _GITHUB_BRANCH
)


def _read_json(path, default=None):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else (default or {})
    except Exception:
        return default or {}


def _atomic_json(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=True)
        os.replace(tmp, path)
        return True
    except Exception as exc:
        log_utils.log('[UpdateChannel] JSON write failed %s: %s' % (path, str(exc)), log_utils.LOGWARNING)
        return False


def _state():
    data = _read_json(_STATE, {})
    if not isinstance(data, dict):
        data = {}
    return data


def _save_state(data):
    return _atomic_json(_STATE, data)


def github_enabled():
    # Fixed public read-only channel. No account credentials are used.
    return True


def github_config():
    return {
        'owner': _GITHUB_OWNER,
        'repo': _GITHUB_REPO,
        'branch': _GITHUB_BRANCH,
        'hotfix_path': _GITHUB_HOTFIX_PATH,
        'manifest_path': _GITHUB_MANIFEST_PATH,
    }


def is_configured():
    return True


def _clean_segment(value):
    return re.sub(r'[^A-Za-z0-9_.-]', '', str(value or ''))


def github_raw_url(path):
    """Return a raw URL inside the fixed public zShip data repository."""
    rel = '/'.join(
        quote(part, safe='._-')
        for part in str(path or '').strip('/').split('/')
        if part
    )
    if not rel:
        return ''
    return _GITHUB_RAW_BASE + rel


def hotfix_url():
    return github_raw_url(_GITHUB_HOTFIX_PATH)


def manifest_url():
    return github_raw_url(_GITHUB_MANIFEST_PATH)

def _fetch_json(url, timeout=6):
    if not url or not url.lower().startswith('https://'):
        raise ValueError('HTTPS URL required')
    req = Request(url, headers={
        'User-Agent': 'zShip-UpdateChannel/1',
        'Accept': 'application/json, text/plain;q=0.9, */*;q=0.1',
        'Cache-Control': 'no-cache',
    })
    response = build_opener().open(req, timeout=timeout)
    raw = response.read(_MAX_JSON + 1)
    try:
        response.close()
    except Exception:
        pass
    if len(raw) > _MAX_JSON:
        raise ValueError('JSON too large')
    data = json.loads(raw.decode('utf-8', 'replace'))
    if not isinstance(data, dict):
        raise ValueError('JSON root must be an object')
    return data


def _version_key(value):
    """Version ordering for zShip's numeric date.build versions."""
    parts = []
    for token in re.findall(r'\d+', str(value or '')):
        try:
            parts.append(int(token))
        except Exception:
            parts.append(0)
    return tuple(parts or [0])


def is_newer(remote, local=None):
    return _version_key(remote) > _version_key(local or control.addonVersion)


def _interval_seconds():
    try:
        minutes = max(30, int(control.getSetting('selfheal.update_interval', '360') or 360))
    except Exception:
        minutes = 360
    return minutes * 60


def check_addon_update(force=False, notify=True):
    """Fetch the public manifest and notify once per newly announced version.

    No executable content is downloaded or installed here.  The manifest is
    metadata only; it tells the user/admin that a package should be distributed.
    """
    url = manifest_url()
    installed = str(control.addonVersion or '')
    result = {
        'configured': bool(url),
        'reachable': False,
        'installed': installed,
        'latest': installed,
        'update_available': False,
        'message': '',
        'download_url': '',
        'error': '',
        'url': url,
    }
    if not url:
        return result

    now = int(time.time())
    state = _state()
    last = int(state.get('last_manifest_check', 0) or 0)
    if not force and now - last < _interval_seconds():
        cached = _read_json(_MANIFEST_PROFILE, {})
        if cached:
            result['reachable'] = True
            result['latest'] = str(cached.get('latest_addon_version') or cached.get('version') or installed)
            result['message'] = str(cached.get('message') or '')
            result['download_url'] = str(cached.get('download_url') or '')
            result['update_available'] = is_newer(result['latest'], installed)
        return result

    state['last_manifest_check'] = now
    _save_state(state)
    try:
        data = _fetch_json(url, timeout=6)
        if int(data.get('schema', 0) or 0) != 1:
            raise ValueError('unsupported manifest schema')
        latest = str(data.get('latest_addon_version') or data.get('version') or '').strip()
        if not latest:
            raise ValueError('latest_addon_version missing')
        _atomic_json(_MANIFEST_PROFILE, data)
        result.update({
            'reachable': True,
            'latest': latest,
            'message': str(data.get('message') or '').strip(),
            'download_url': str(data.get('download_url') or '').strip(),
            'update_available': is_newer(latest, installed),
        })
        log_utils.log(
            '[UpdateChannel] manifest OK installed=%s latest=%s update=%s'
            % (installed, latest, str(result['update_available'])),
            log_utils.LOGINFO
        )
        if result['update_available'] and notify and control.getSetting('selfheal.update_notify', 'true') != 'false':
            state = _state()
            already = str(state.get('notified_addon_version') or '')
            if already != latest:
                msg = 'Neue zShip-Version %s verfügbar' % latest
                if result['message']:
                    msg += ': ' + result['message'][:160]
                control.infoDialog(msg, heading='zShip Update', icon='INFO', time=9000, sound=False)
                state['notified_addon_version'] = latest
                _save_state(state)
        return result
    except Exception as exc:
        result['error'] = str(exc)
        log_utils.log('[UpdateChannel] manifest check failed: %s' % str(exc), log_utils.LOGINFO)
        cached = _read_json(_MANIFEST_PROFILE, {})
        if cached:
            result['latest'] = str(cached.get('latest_addon_version') or cached.get('version') or installed)
            result['message'] = str(cached.get('message') or '')
            result['download_url'] = str(cached.get('download_url') or '')
            result['update_available'] = is_newer(result['latest'], installed)
        return result


def configuration_summary():
    return '%s/%s @ %s (public read-only)' % (
        _GITHUB_OWNER, _GITHUB_REPO, _GITHUB_BRANCH
    )
