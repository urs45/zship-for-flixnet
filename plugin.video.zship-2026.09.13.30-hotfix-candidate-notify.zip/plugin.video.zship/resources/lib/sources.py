# edit 2025-06-12
import sys
import re, json, random, time, threading, traceback
from urllib.parse import urlparse, urlunparse, urljoin, unquote_plus, quote_plus as url_quote_plus
from urllib.request import Request, build_opener, HTTPCookieProcessor
from http.cookiejar import CookieJar
from concurrent.futures import ThreadPoolExecutor
from resources.lib import log_utils, utils, control, hotfix
from resources.lib.utils import get_titles
from resources.lib.control import py2_decode, py2_encode, quote_plus, parse_qsl
import resolveurl as resolver
# from functools import reduce
from resources.lib.control import getKodiVersion

if int(getKodiVersion()) >= 20: from infotagger.listitem import ListItemInfoTag

# für self.sysmeta - zur späteren verwendung als meta
_params = dict(parse_qsl(sys.argv[2].replace('?',''))) if len(sys.argv) > 1 else dict()

class sources:
    def __init__(self):
        self.getConstants()
        self.sources = []
        self._sources_lock = threading.Lock()
        self.tmdb_id = None
        self.current = int(time.time())
        if 'sysmeta' in _params: self.sysmeta = _params['sysmeta'] # string zur späteren verwendung als meta
        self.watcher = False
        self.executor = ThreadPoolExecutor(max_workers=20)
        self.url = None

    def get(self, params):
        data = json.loads(params['sysmeta'])
        self.mediatype = data.get('mediatype')
        self.aliases = data.get('aliases') if 'aliases' in data else []

        title = py2_encode(data.get('title'))
        originaltitle = py2_encode(data.get('originaltitle')) if 'originaltitle' in data else title
        year = data.get('year') if 'year' in data else None
        imdb = data.get('imdb_id') if 'imdb_id' in data else data.get('imdbnumber') if 'imdbnumber' in data else None
        if not imdb and 'imdb' in data: imdb = data.get('imdb')
        tmdb = data.get('tmdb_id') if 'tmdb_id' in data else data.get('tmdb') if 'tmdb' in data else None
        self.tmdb_id = tmdb
        season = data.get('season') if 'season' in data else 0
        episode = data.get('episode') if 'episode' in data else 0
        premiered = data.get('premiered') if 'premiered' in data else None
        meta = params['sysmeta']
        select = data.get('select') if 'select' in data else None
        return title, year, imdb, season, episode, originaltitle, premiered, meta, select

    def play(self, params):
        title, year, imdb, season, episode, originaltitle, premiered, meta, select = self.get(params)
        try:
            url = None
            #Liste der gefundenen Streams
            items = self.getSources(title, year, imdb, season, episode, originaltitle, premiered)
            select = control.getSetting('hosts.mode') if select == None else select
            ## unnötig
            #select = '1' if control.getSetting('downloads') == 'true' and not (control.getSetting('download.movie.path') == '' or control.getSetting('download.tv.path') == '') else select

            # # TODO überprüfen wofür mal gedacht
            # if control.window.getProperty('PseudoTVRunning') == 'True':
            #     return control.resolveUrl(int(sys.argv[1]), True, control.item(path=str(self.sourcesDirect(items))))

            if len(items) > 0:
                # Auswahl Verzeichnis
                if select == '1' and 'plugin' in control.infoLabel('Container.PluginName'):
                    control.window.clearProperty(self.itemsProperty)
                    control.window.setProperty(self.itemsProperty, json.dumps(items))
                    
                    control.window.clearProperty(self.metaProperty)
                    control.window.setProperty(self.metaProperty, meta)
                    control.sleep(2)
                    return control.execute('Container.Update(%s?action=addItem&title=%s)' % (sys.argv[0], quote_plus(title)))
                # Auswahl Dialog
                elif select == '0' or select == '1':
                    url = self.sourcesDialog(items)
                    if  url == 'close://': return
                # Autoplay
                else:
                    url = self.sourcesDirect(items)

            if url == None: return self.errorForSources()

            try: meta = json.loads(meta)
            except: pass

            from resources.lib.player import player
            player().run(title, url, meta)
        except Exception as e:
            log_utils.log('Error %s' % str(e), log_utils.LOGERROR)


# Liste gefundene Streams Indexseite|Hoster
    def addItem(self, title):
        """Build the Kodi result directory from already found sources.

        Keep source rows independent from optional metadata enrichment. Kodi 20+
        infotagger is strict about malformed/None values (especially episode
        metadata). A metadata error must never make a valid stream disappear.
        """
        control.playlist.clear()

        try:
            raw_items = control.window.getProperty(self.itemsProperty)
            items = json.loads(raw_items) if raw_items else []
        except Exception as e:
            log_utils.log('Result list: invalid items property: %s' % str(e), log_utils.LOGERROR)
            items = []

        if not items:
            log_utils.log('Result list: no stored sources available', log_utils.LOGWARNING)
            control.idle()
            return

        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])
        systitle = sysname = quote_plus(title)

        try:
            raw_meta = control.window.getProperty(self.metaProperty)
            meta = json.loads(raw_meta) if raw_meta else {}
        except Exception as e:
            log_utils.log('Result list: invalid meta property: %s' % str(e), log_utils.LOGERROR)
            meta = {}

        mediatype = meta.get('mediatype', '')
        if mediatype == 'movie':
            downloads = True if control.getSetting('downloads') == 'true' and control.getSetting('download.movie.path') else False
        else:
            downloads = True if control.getSetting('downloads') == 'true' and control.getSetting('download.tv.path') else False

        addonPoster, addonBanner = control.addonPoster(), control.addonBanner()
        addonFanart, settingFanart = control.addonFanart(), control.getSetting('fanart')

        def _http_art(value, fallback):
            try:
                value = py2_decode(value) if value is not None else ''
                return value if isinstance(value, str) and value.startswith(('http://', 'https://')) else fallback
            except Exception:
                return fallback

        fanart = _http_art(meta.get('backdrop_url') or meta.get('fanart'), addonFanart)
        poster = _http_art(meta.get('cover_url') or meta.get('poster'), addonPoster)
        sysimage = poster

        try:
            if meta.get('season') is not None and meta.get('episode') is not None:
                sysname += quote_plus(' S%02dE%02d' % (int(meta.get('season')), int(meta.get('episode'))))
            elif meta.get('year') is not None:
                sysname += quote_plus(' (%s)' % meta.get('year'))
        except Exception as e:
            log_utils.log('Result list: could not build media filename: %s' % str(e), log_utils.LOGWARNING)

        added = 0
        for idx, source_item in enumerate(items):
            try:
                # The source row itself only needs a label and playback URL.
                # Never drop it because optional metadata cannot be applied.
                label = source_item.get('label') or '%02d | %s | %s' % (
                    idx + 1,
                    str(source_item.get('provider', '?')).upper(),
                    str(source_item.get('source', '?')).upper())
                syssource = quote_plus(json.dumps([source_item]))

                item = control.item(label=label, offscreen=True)
                item.setProperty('IsPlayable', 'true')
                try:
                    item.setArt({'poster': poster, 'banner': addonBanner})
                    if settingFanart == 'true' and fanart:
                        item.setProperty('Fanart_Image', fanart)
                except Exception as e:
                    log_utils.log('Result list art failed for %s: %s' % (label, str(e)), log_utils.LOGWARNING)

                try:
                    cm = []
                    if downloads:
                        cm.append(("Download", 'RunPlugin(%s?action=download&name=%s&image=%s&source=%s)' % (sysaddon, sysname, sysimage, syssource)))
                    if control.getSetting('jd_enabled') == 'true':
                        cm.append(("Sende zum JDownloader", 'RunPlugin(%s?action=sendToJD&name=%s&source=%s)' % (sysaddon, sysname, syssource)))
                    if control.getSetting('jd2_enabled') == 'true':
                        cm.append(("Sende zum JDownloader2", 'RunPlugin(%s?action=sendToJD2&name=%s&source=%s)' % (sysaddon, sysname, syssource)))
                    if control.getSetting('myjd_enabled') == 'true':
                        cm.append(("Sende zu My.JDownloader", 'RunPlugin(%s?action=sendToMyJD&name=%s&source=%s)' % (sysaddon, sysname, syssource)))
                    if control.getSetting('pyload_enabled') == 'true':
                        cm.append(("Sende zu PyLoad", 'RunPlugin(%s?action=sendToPyLoad&name=%s&source=%s)' % (sysaddon, sysname, syssource)))
                    cm.append(("Medien-Info", 'RunPlugin(%s?action=mediaInfo&source=%s)' % (sysaddon, syssource)))
                    cm.append(('Einstellungen', 'RunPlugin(%s?action=addonSettings)' % sysaddon))
                    item.addContextMenuItems(cm)
                except Exception as e:
                    log_utils.log('Result list context menu failed for %s: %s' % (label, str(e)), log_utils.LOGWARNING)

                # Carry the identification payload in the playback URL as well as
                # in the window property.  A new plugin invocation is created when a
                # source row is clicked; relying only on a window property can lose or
                # stale the TMDbHelper IDs before the final resolved ListItem is built.
                tracking_keys = (
                    'mediatype', 'title', 'originaltitle', 'tvshowtitle', 'showtitle',
                    'showname', 'year', 'imdb_id', 'imdbnumber', 'imdb', 'tmdb_id',
                    'tmdb', 'tvdb_id', 'tvdb', 'season', 'episode', 'premiered'
                )
                tracking_meta = {k: meta.get(k) for k in tracking_keys if meta.get(k) not in (None, '')}
                systracking = quote_plus(json.dumps(tracking_meta, separators=(',', ':')))
                url = "%s?action=playItem&title=%s&source=%s&sysmeta=%s" % (
                    sysaddon, systitle, syssource, systracking)

                # Optional metadata. Failure here must not suppress the row.
                try:
                    season_val = meta.get('season')
                    episode_val = meta.get('episode')
                    if season_val is not None and episode_val is not None:
                        name = '%s\nStaffel: %s   Episode: %s' % (title, season_val, episode_val)
                    else:
                        name = title

                    raw_plot = meta.get('plot')
                    plot_text = raw_plot.strip() if isinstance(raw_plot, str) else ''
                    plot = '[COLOR blue]%s[/COLOR]\n\n%s' % (name, py2_encode(plot_text))
                    infolabel = {'plot': plot}

                    duration = meta.get('duration')
                    try:
                        if duration is not None and str(duration).strip() != '':
                            duration_int = int(float(duration))
                            if duration_int > 0:
                                infolabel['duration'] = duration_int
                    except Exception:
                        pass

                    q = str(source_item.get('quality', ''))
                    label_l = str(label).lower()
                    video_streaminfo = {}
                    audio_streaminfo = {}
                    if '4k' in q.lower():
                        video_streaminfo.update({'width': 3840, 'height': 2160})
                    elif '1080p' in q.lower():
                        video_streaminfo.update({'width': 1920, 'height': 1080})
                    elif 'hd' in q.lower() or '720p' in q.lower():
                        video_streaminfo.update({'width': 1280, 'height': 720})

                    if 'hevc' in label_l:
                        video_streaminfo['codec'] = 'hevc'
                    elif '265' in label_l:
                        video_streaminfo['codec'] = 'h265'
                    elif 'mkv' in label_l:
                        video_streaminfo['codec'] = 'mkv'
                    elif 'mp4' in label_l:
                        video_streaminfo['codec'] = 'mp4'

                    if 'dts' in label_l:
                        audio_streaminfo['codec'] = 'dts'
                    elif 'plus' in label_l or 'e-ac3' in label_l:
                        audio_streaminfo['codec'] = 'eac3'
                    elif 'dolby' in label_l or 'ac3' in label_l:
                        audio_streaminfo['codec'] = 'ac3'

                    info_l = str(source_item.get('info', '')).lower()
                    if '7.1' in info_l:
                        audio_streaminfo['channels'] = 8
                    elif '5.1' in info_l:
                        audio_streaminfo['channels'] = 6

                    if int(getKodiVersion()) <= 19:
                        item.setInfo(type='Video', infoLabels=infolabel)
                        if video_streaminfo:
                            item.addStreamInfo('video', video_streaminfo)
                        if audio_streaminfo:
                            item.addStreamInfo('audio', audio_streaminfo)
                    else:
                        info_tag = ListItemInfoTag(item, 'video')
                        info_tag.set_info(infolabel)
                        stream_details = {}
                        if video_streaminfo:
                            stream_details['video'] = [video_streaminfo]
                        if audio_streaminfo:
                            stream_details['audio'] = [audio_streaminfo]
                        if stream_details:
                            info_tag.set_stream_details(stream_details)
                except Exception as e:
                    log_utils.log('Result list metadata failed for %s: %s' % (label, str(e)), log_utils.LOGWARNING)

                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
                added += 1
            except Exception as e:
                log_utils.log('Result list row %d failed: %s | source=%s' % (idx + 1, str(e), str(source_item)), log_utils.LOGERROR)

        log_utils.log('Result list: stored=%d added=%d media=%s S%sE%s' % (
            len(items), added, mediatype, str(meta.get('season', '')), str(meta.get('episode', ''))), log_utils.LOGWARNING)

        control.idle()
        control.content(syshandle, 'videos')
        control.plugincategory(syshandle, control.addonVersion)
        control.endofdirectory(syshandle, cacheToDisc=True)


    def playItem(self, title, source):
        isDebug = False
        if isDebug: log_utils.log('start playItem', log_utils.LOGWARNING)
        try:
            # Start with the full metadata cached while the result list was built,
            # then overlay the compact identification payload carried by the clicked
            # source URL.  This keeps artwork/plot while guaranteeing that IDs and
            # S/E numbers survive the second plugin invocation.
            meta = {}
            try:
                raw_meta = control.window.getProperty(self.metaProperty)
                if raw_meta:
                    cached_meta = json.loads(raw_meta)
                    if isinstance(cached_meta, dict):
                        meta.update(cached_meta)
            except Exception as e:
                log_utils.log('playItem cached metadata error: %s' % str(e), log_utils.LOGWARNING)

            try:
                raw_tracking = _params.get('sysmeta')
                if raw_tracking:
                    tracking_meta = json.loads(raw_tracking)
                    if isinstance(tracking_meta, dict):
                        meta.update(tracking_meta)
            except Exception as e:
                log_utils.log('playItem tracking metadata error: %s' % str(e), log_utils.LOGWARNING)

            header = control.addonInfo('name')
            # control.idle() #ok
            progressDialog = control.progressDialog if control.getSetting('progress.dialog') == '0' else control.progressDialogBG
            progressDialog.create(header, '')
            progressDialog.update(0)

            item = json.loads(source)[0]
            #if isDebug: log_utils.log('playItem 237', log_utils.LOGWARNING)
            if item['source'] == None: raise Exception()

            log_utils.log(
                '[PlaybackSelect] provider=%s | hoster=%s | quality=%s | '
                'direct=%s | label=%s'
                % (
                    str(item.get('provider', '')),
                    str(item.get('source', '')),
                    str(item.get('quality', '')),
                    str(item.get('direct', False)),
                    str(item.get('label', ''))
                ),
                log_utils.LOGWARNING
            )
            
            future = self.executor.submit(self.sourcesResolve, item)
            
            waiting_time = 30
            while waiting_time > 0:
                try:
                    if control.abortRequested: return sys.exit()
                    if progressDialog.iscanceled(): return progressDialog.close()
                except:
                    pass
                if future.done(): break
                control.sleep(1)
                waiting_time = waiting_time - 1
                progressDialog.update(int(100 - 100. / 30 * waiting_time), str(item['label']))
                #if isDebug: log_utils.log('playItem 252', log_utils.LOGWARNING)
                if control.condVisibility('Window.IsActive(virtualkeyboard)') or \
                        control.condVisibility('Window.IsActive(yesnoDialog)'):
                        # or control.condVisibility('Window.IsActive(PopupRecapInfoWindow)'):
                    waiting_time = waiting_time + 1  # dont count down while dialog is presented
                if future.done(): break

            try: progressDialog.close()
            except: pass
            if isDebug: log_utils.log('playItem 261', log_utils.LOGWARNING)
            control.execute('Dialog.Close(virtualkeyboard)')
            control.execute('Dialog.Close(yesnoDialog)')

            if isDebug: log_utils.log('playItem url: %s' % self.url, log_utils.LOGWARNING)
            if self.url == None:
                #self.errorForSources()
                return

            log_utils.log(
                '[PlaybackSelect] KODI provider=%s | hoster=%s | quality=%s | '
                'final=%s'
                % (
                    str(item.get('provider', '')),
                    str(item.get('source', '')),
                    str(item.get('quality', '')),
                    str(self.url)
                ),
                log_utils.LOGWARNING
            )

            from resources.lib.player import player
            player().run(title, self.url, meta)
            return self.url
        except Exception as e:
            log_utils.log('Error %s' % str(e), log_utils.LOGERROR)


    def getSources(self, title, year, imdb, season, episode, originaltitle, premiered, quality='HD', timeout=30):
#TODO
        # self._getHostDict()
        control.idle() #ok
        progressDialog = control.progressDialog if control.getSetting('progress.dialog') == '0' else control.progressDialogBG
        progressDialog.create(control.addonInfo('name'), '')
        progressDialog.update(0)
        progressDialog.update(0, "Quellen werden vorbereitet")

        sourceDict = self.sourceDict
        sourceDict = [(i[0], i[1], i[1].priority) for i in sourceDict]
        random.shuffle(sourceDict)
        sourceDict = sorted(sourceDict, key=lambda i: i[2])
        content = 'movies' if season == 0 or season == '' or season == None else 'shows'
        titles = get_titles(title, originaltitle, imdb, content)
        # Preserve aliases supplied in sysmeta by zShip as additional search titles.
        for alias in self.aliases:
            if alias and str(alias).lower() not in [str(t).lower() for t in titles]:
                titles.append(alias)

        futures = {self.executor.submit(self._getSource, titles, year, season, episode, imdb, provider[0], provider[1]): provider[0] for provider in sourceDict}
        provider_names = {provider[0].upper() for provider in sourceDict}

        string4 = "Total"

        try: timeout = int(control.getSetting('scrapers.timeout'))
        except: pass
        
        quality = control.getSetting('hosts.quality')
        if quality == '': quality = '0'

        source_4k = 0
        source_1080 = 0
        source_720 = 0
        source_sd = 0
        total = d_total = 0
        total_format = '[COLOR %s][B]%s[/B][/COLOR]'
        pdiag_format = ' 4K: %s | 1080p: %s | 720p: %s | SD: %s | %s: %s                                         '.split('|')

        for i in range(0, 4 * timeout):
            try:
                if control.abortRequested: return sys.exit()
                try:
                    if progressDialog.iscanceled(): break
                except:
                    pass

                if len(self.sources) > 0:
                    if quality in ['0']:
                        source_4k = len([e for e in self.sources if e['quality'] == '4K'])
                        source_1080 = len([e for e in self.sources if e['quality'] in ['1440p','1080p']])
                        source_720 = len([e for e in self.sources if e['quality'] in ['720p','HD']])
                        source_sd = len([e for e in self.sources if e['quality'] not in ['4K','1440p','1080p','720p','HD']])
                    elif quality in ['1']:
                        source_1080 = len([e for e in self.sources if e['quality'] in ['1440p','1080p']])
                        source_720 = len([e for e in self.sources if e['quality'] in ['720p','HD']])
                        source_sd = len([e for e in self.sources if e['quality'] not in ['4K','1440p','1080p','720p','HD']])
                    elif quality in ['2']:
                        source_1080 = len([e for e in self.sources if e['quality'] in ['1080p']])
                        source_720 = len([e for e in self.sources if e['quality'] in ['720p','HD']])
                        source_sd = len([e for e in self.sources if e['quality'] not in ['4K','1440p','1080p','720p','HD']])
                    elif quality in ['3']:
                        source_720 = len([e for e in self.sources if e['quality'] in ['720p','HD']])
                        source_sd = len([e for e in self.sources if e['quality'] not in ['4K','1440p','1080p','720p','HD']])
                    else:
                        source_sd = len([e for e in self.sources if e['quality'] not in ['4K','1440p','1080p','720p','HD']])

                    total = source_4k + source_1080 + source_720 + source_sd

                source_4k_label = total_format % ('red', source_4k) if source_4k == 0 else total_format % ('lime', source_4k)
                source_1080_label = total_format % ('red', source_1080) if source_1080 == 0 else total_format % ('lime', source_1080)
                source_720_label = total_format % ('red', source_720) if source_720 == 0 else total_format % ('lime', source_720)
                source_sd_label = total_format % ('red', source_sd) if source_sd == 0 else total_format % ('lime', source_sd)
                source_total_label = total_format % ('red', total) if total == 0 else total_format % ('lime', total)

                try:
                    info = [name.upper() for future, name in futures.items() if not future.done()]

                    percent = int(100 * float(i) / (2 * timeout) + 1)

                    if quality in ['0']:
                        line1 = '|'.join(pdiag_format) % (source_4k_label, source_1080_label, source_720_label, source_sd_label, str(string4), source_total_label)
                    elif quality in ['1']:
                        line1 = '|'.join(pdiag_format[1:]) % (source_1080_label, source_720_label, source_sd_label, str(string4), source_total_label)
                    elif quality in ['2']:
                        line1 = '|'.join(pdiag_format[1:]) % (source_1080_label, source_720_label, source_sd_label, str(string4), source_total_label)
                    elif quality in ['3']:
                        line1 = '|'.join(pdiag_format[2:]) % (source_720_label, source_sd_label, str(string4), source_total_label)
                    else:
                        line1 = '|'.join(pdiag_format[3:]) % (source_sd_label, str(string4), source_total_label)

                    if (i / 2) < timeout:
                        string = "Verbleibende Indexseiten: %s"
                    else:
                        string = 'Waiting for: %s'

                    if len(info) > 6: line = line1 + string % (str(len(info)))
                    elif len(info) > 1: line = line1 + string % (', '.join(info))
                    elif len(info) == 1: line = line1 + string % (''.join(info))
                    else: line = line1 + 'Suche beendet!'

                    progressDialog.update(max(1, percent), line)
                    if len(info) == 0: break

                except Exception as e:
                    log_utils.log('Exception Raised: %s' % str(e), log_utils.LOGERROR)

                control.sleep(1)
            except:
                pass

        time.sleep(1)

        try: progressDialog.close()
        except: pass
        self.sourcesFilter()
        return self.sources


    def _getSource(self, titles, year, season, episode, imdb, source, call):
        started = time.time()
        raw_count = 0
        hotfix.begin_provider_run(source)
        try:
            try:
                call.tmdb_id = self.tmdb_id
                call.imdb_id = imdb
                call.media_type = 'movie' if not season else 'episode'
                call.requested_season = season
                call.requested_episode = episode
            except Exception:
                pass

            title_dbg = titles[0] if titles else ''
            configured_domain = getattr(call, 'domain', '')
            log_utils.log(
                '[ProviderDiag] START %s | title=%s year=%s S%sE%s '
                'imdb=%s tmdb=%s domain=%s'
                % (
                    source, str(title_dbg), str(year), str(season or 0),
                    str(episode or 0), str(imdb or ''),
                    str(self.tmdb_id or ''), str(configured_domain or '')
                ),
                log_utils.LOGINFO,
            )

            rows = call.run(titles, year, season, episode, imdb)
            raw_count = len(rows) if isinstance(rows, list) else 0

            if not rows:
                log_utils.log(
                    '[ProviderDiag] ZERO %s | %.3fs | raw=%d'
                    % (source, time.time() - started, raw_count),
                    log_utils.LOGINFO,
                )
                return

            rows = [
                json.loads(t)
                for t in set(json.dumps(d, sort_keys=True) for d in rows)
            ]
            accepted = []
            force_lazy = hotfix.should_force_lazy(source)
            for item in rows:
                if not isinstance(item, dict):
                    continue
                item.update({'provider': source})
                if 'priority' not in item:
                    item.update({'priority': 100})
                if 'prioHoster' not in item:
                    item.update({'prioHoster': 100})
                # If SelfHeal detected/declared an eager-resolve provider, any
                # non-media HTTP URL is treated as a hoster page and resolved
                # only after selection. This completes the automatic lazy mode
                # even when the provider itself still says direct=True.
                if force_lazy and not self._is_direct_media_url(item.get('url')):
                    item['direct'] = False
                accepted.append(item)

            with self._sources_lock:
                self.sources.extend(accepted)

            log_utils.log(
                '[ProviderDiag] DONE %s | %.3fs | raw=%d accepted=%d'
                % (
                    source, time.time() - started, raw_count, len(accepted)
                ),
                log_utils.LOGINFO,
            )
        except Exception as e:
            log_utils.log(
                '[ProviderDiag] ERROR %s | %.3fs | %s'
                % (source, time.time() - started, str(e)),
                log_utils.LOGERROR,
            )
            log_utils.log(
                '[ProviderDiag] TRACE %s | %s'
                % (source, traceback.format_exc()),
                log_utils.LOGERROR,
            )
        finally:
            try:
                hotfix.finish_provider_run(
                    source, time.time() - started, raw_count=raw_count
                )
            except Exception:
                pass


    def sourcesFilter(self):
        before_count = len(self.sources)
        before_by_provider = {}
        for _row in self.sources:
            if isinstance(_row, dict):
                _p = _row.get('provider', '?')
                before_by_provider[_p] = before_by_provider.get(_p, 0) + 1
        log_utils.log(
            'Source filter start: %d rows | providers=%s'
            % (before_count, str(before_by_provider)),
            log_utils.LOGWARNING
        )
        # Drop only structurally unusable rows; one malformed provider result must not abort the full list.
        valid_rows = []
        for row in self.sources:
            try:
                if not isinstance(row, dict):
                    continue
                if not row.get('url') or not row.get('source'):
                    continue
                row.setdefault('quality', 'SD')
                row.setdefault('language', 'de')
                row.setdefault('info', '')
                row.setdefault('direct', False)
                row.setdefault('priority', 100)
                row.setdefault('prioHoster', 100)
                valid_rows.append(row)
            except Exception as e:
                log_utils.log('Source filter invalid row: %s' % str(e), log_utils.LOGWARNING)
        self.sources = valid_rows
        after_by_provider = {}
        for _row in self.sources:
            _p = _row.get('provider', '?')
            after_by_provider[_p] = after_by_provider.get(_p, 0) + 1
        log_utils.log(
            'Source structural filter: %d -> %d | providers=%s'
            % (before_count, len(self.sources), str(after_by_provider)),
            log_utils.LOGWARNING
        )
        # hostblockDict = utils.getHostDict()
        # self.sources = [i for i in self.sources if i['source'].split('.')[0] not in str(hostblockDict)] # Hoster ausschließen (Liste)

        quality = control.getSetting('hosts.quality')
        if quality == '': quality = '0'

        random.shuffle(self.sources)

        self.sources = sorted(self.sources, key=lambda k: k['prioHoster'], reverse=False)

        for i in range(len(self.sources)):
            q = self.sources[i]['quality']            
            if q.lower() == 'hd': self.sources[i].update({'quality': '720p'})

        filter = []
        if quality in ['0']: filter += [i for i in self.sources if i['quality'] == '4K']
        if quality in ['0', '1']: filter += [i for i in self.sources if i['quality'] == '1440p']
        if quality in ['0', '1', '2']: filter += [i for i in self.sources if i['quality'] == '1080p']
        if quality in ['0', '1', '2', '3']: filter += [i for i in self.sources if i['quality'] == '720p']
        #filter += [i for i in self.sources if i['quality'] in ['SD', 'SCR', 'CAM']]
        filter += [i for i in self.sources if i['quality'] not in ['4k', '1440p', '1080p', '720p']]
        self.sources = filter

        if control.getSetting('hosts.sort.provider') == 'true':
            self.sources = sorted(self.sources, key=lambda k: (k.get('prioHoster', 0) >= 999, k['provider']))

        if control.getSetting('hosts.sort.priority') == 'true' and self.mediatype == 'tvshow': self.sources = sorted(self.sources, key=lambda k: (k.get('prioHoster', 0) >= 999, k['priority']), reverse=False)

        # Learned failures only push a provider+hoster pair later; they never
        # hide it permanently. A subsequent success automatically repairs the
        # score, so transient outages heal themselves.
        self.sources = sorted(
            self.sources,
            key=lambda k: hotfix.pair_penalty(
                k.get('provider', ''), k.get('source', '')
            )
        )

        if str(control.getSetting('hosts.limit')) == 'true':
            self.sources = self.sources[:int(control.getSetting('hosts.limit.num'))]
        else:
            self.sources = self.sources[:100]

        for i in range(len(self.sources)):
            p = self.sources[i]['provider']
            q = self.sources[i]['quality']
            s = self.sources[i]['source']
            ## s = s.rsplit('.', 1)[0]
            l = self.sources[i]['language']

            try: f = (' | '.join(['[I]%s [/I]' % info.strip() for info in self.sources[i]['info'].split('|')]))
            except: f = ''

            label = '%02d | [B]%s[/B] | ' % (int(i + 1), p)
            if q in ['4K', '1440p', '1080p', '720p']: label += '%s | [B][I]%s [/I][/B] | %s' % (s, q, f)
            elif q == 'SD': label += '%s | %s' % (s, f)
            else: label += '%s | %s | [I]%s [/I]' % (s, f, q)
            label = label.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
            label = re.sub(r'\[I\]\s+\[/I\]', ' ', label)
            label = re.sub(r'\|\s+\|', '|', label)
            label = re.sub(r'\|(?:\s+|)$', '', label)

            if self.sources[i].get('prioHoster', 0) >= 999:
                label += ' | [COLOR red]CAPTCHA[/COLOR]'
            self.sources[i]['label'] = label.upper()

            # ## EMBY shown as premium link ##
            # if self.sources[i]['provider']=="emby" or self.sources[i]['provider']=="amazon" or self.sources[i]['provider']=="netflix" or self.sources[i]['provider']=="maxdome":
            #     prem_identify = 'blue'
            #     self.sources[i]['label'] = ('[COLOR %s]' % (prem_identify)) + label.upper() + '[/COLOR]'

        self.sources = [i for i in self.sources if 'label' in i]
        log_utils.log('Source filter end: %d -> %d rows' % (before_count, len(self.sources)), log_utils.LOGWARNING)
        return self.sources


    @staticmethod
    def _is_direct_media_url(url):
        """Conservative test for URLs Kodi can reasonably receive directly."""
        try:
            text = str(url or '').strip()
            if not text:
                return False
            base = text.split('|', 1)[0]
            parsed = urlparse(base)
            path = (parsed.path or '').lower()
            return path.endswith((
                '.m3u8', '.mp4', '.mpd', '.mkv', '.webm',
                '.m4v', '.mov', '.avi', '.ts', '.m2ts'
            ))
        except Exception:
            return False

    @staticmethod
    def _looks_like_hoster_page(url):
        """
        Detect an obvious hoster *web page* that must not be handed to Kodi.

        Deliberately conservative so extensionless signed CDN streams are not
        rejected merely because they have no filename extension.
        """
        try:
            text = str(url or '').strip()
            parsed = urlparse(text.split('|', 1)[0])
            host = (parsed.hostname or '').lower()
            path = (parsed.path or '').lower()

            known_page_hosts = (
                'dood', 'doood', 'voe.', 'mixdrop', 'dr0pstream',
                'dropstream', 'streamtape', 'filemoon', 'vidoza',
                'vidhide', 'streamwish', 'lulustream', 'veev.',
                'vidmoly', 'upstream', 'streamlare'
            )
            hosterish = any(token in host for token in known_page_hosts)
            page_path = (
                path.startswith('/e/') or
                path.startswith('/w/') or
                path.startswith('/d/') or
                '/embed' in path or
                path.endswith('.html')
            )
            return hosterish and page_path
        except Exception:
            return False

    @staticmethod
    def _dood_parts(url):
        try:
            text = str(url or '').strip()
            parsed = urlparse(text.split('|', 1)[0])
            host = (parsed.hostname or '').lower()
            path = parsed.path or ''
            dood_hosts = {
                'dood.watch', 'doodstream.com', 'dood.to', 'dood.so',
                'dood.cx', 'dood.la', 'dood.ws', 'dood.sh',
                'doodstream.co', 'dood.pm', 'dood.wf', 'dood.re',
                'dood.yt', 'dooood.com', 'dood.stream', 'dood.li',
                'dood.work', 'vide0.net', 'vvide0.com', 'playmogo.com',
                'myvidplay.com', 'd-s.io', 'dsvplay.com', 'ds2play.com',
                'ds2video.com', 'd0o0d.com', 'do0od.com', 'd0000d.com',
                'd000d.com', 'dooodster.com', 'all3do.com', 'do7go.com',
                'doodcdn.io', 'doply.net', 'doods.pro'
            }
            m = re.match(r'^/(w|d|e)/([0-9A-Za-z]+)/*$', path, re.I)
            if host in dood_hosts and m:
                return host, m.group(2), m.group(1).lower()
        except Exception:
            pass
        return '', '', ''

    @classmethod
    def _resolve_alias_candidates(cls, url):
        text = str(url or '').strip()
        if not text:
            return []

        host, media_id, path_type = cls._dood_parts(text)
        if not media_id:
            return [text]

        candidates = []
        if path_type in ('d', 'e'):
            candidates.append(text)
        candidates.append('https://%s/d/%s' % (host, media_id))
        candidates.append('https://playmogo.com/d/%s' % media_id)

        result = []
        for candidate in candidates:
            if candidate and candidate not in result:
                result.append(candidate)
        return result

    @classmethod
    def _is_dood_url(cls, url):
        return bool(cls._dood_parts(url)[1])

    @classmethod
    def _resolve_dood_default_tls(cls, url):
        host, media_id, _path_type = cls._dood_parts(url)
        if not media_id:
            return None, 'not_dood'

        ua = (
            'Mozilla/5.0 (Linux; Android 10; K) '
            'AppleWebKit/537.36 (KHTML, like Gecko) '
            'Chrome/148.0.0.0 Mobile Safari/537.36'
        )

        candidate_hosts = []
        for value in (host, 'playmogo.com', 'doodstream.com'):
            if value and value not in candidate_hosts:
                candidate_hosts.append(value)

        last_reason = 'dood_default_tls_failed'

        for candidate_host in candidate_hosts:
            try:
                jar = CookieJar()
                opener = build_opener(HTTPCookieProcessor(jar))

                web_url = 'https://%s/d/%s' % (candidate_host, media_id)
                root_ref = 'https://%s/' % candidate_host
                headers = {'User-Agent': ua, 'Referer': root_ref}

                response = opener.open(
                    Request(web_url, headers=headers), timeout=12
                )
                final_url = response.geturl() or web_url
                html_text = response.read().decode('utf-8', 'ignore')

                final_host = (urlparse(final_url).hostname or candidate_host)
                if final_host != candidate_host:
                    candidate_host = final_host
                    web_url = 'https://%s/d/%s' % (
                        candidate_host, media_id
                    )

                headers['Referer'] = web_url

                iframe = re.search(
                    r'<iframe\\s*src=["\\\']([^"\\\']+)',
                    html_text,
                    re.I
                )
                if iframe:
                    embed_url = urljoin(web_url, iframe.group(1))
                else:
                    embed_url = web_url.replace('/d/', '/e/')

                player_html = opener.open(
                    Request(embed_url, headers=headers), timeout=12
                ).read().decode('utf-8', 'ignore')

                match = re.search(
                    r"dsplayer\\.hotkeys[^']+'([^']+).+?"
                    r"function\\s*makePlay.+?return[^?]+([^\\\"]+)",
                    player_html,
                    re.I | re.S
                )
                if not match:
                    last_reason = 'dood_default_tls_no_player_token'
                    continue

                pass_url = urljoin(web_url, match.group(1))
                token = match.group(2)

                pass_text = opener.open(
                    Request(pass_url, headers=headers), timeout=12
                ).read().decode('utf-8', 'ignore').strip()

                if not pass_text:
                    last_reason = 'dood_default_tls_empty_pass'
                    continue

                if 'cloudflarestorage.' in pass_text:
                    stream_url = pass_text
                else:
                    alphabet = (
                        'abcdefghijklmnopqrstuvwxyz'
                        'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
                    )
                    random_tail = ''.join(
                        random.choice(alphabet) for _ in range(10)
                    )
                    stream_url = (
                        pass_text + random_tail + token
                        + str(int(time.time() * 1000))
                    )

                pipe = (
                    '|User-Agent=%s&Referer=%s'
                    % (
                        url_quote_plus(ua),
                        url_quote_plus(embed_url),
                    )
                )
                log_utils.log(
                    '[PlaybackResolve] Dood Kodi21 default-TLS fallback OK '
                    '| host=%s | id=%s'
                    % (candidate_host, media_id),
                    log_utils.LOGWARNING
                )
                return stream_url + pipe, 'ok'

            except Exception as exc:
                last_reason = 'dood_default_tls_exception:%s' % str(exc)

        return None, last_reason

    def _resolve_with_resolveurl(self, url, allow_popups=False):
        """
        Resolve a hoster page.

        Returns: (resolved_url, reason, attempted_url)
        Unknown resolver domains are failures, never pass-through URLs.
        """
        last_reason = 'no_resolver'
        attempted = str(url or '')

        is_dood = self._is_dood_url(url)

        _host, _media_id, _path_type = self._dood_parts(url)
        if is_dood and _path_type == 'w':
            dood_url, dood_reason = self._resolve_dood_default_tls(url)
            if dood_url:
                return dood_url, 'ok', str(url)
            last_reason = dood_reason
            log_utils.log(
                '[PlaybackResolve] Dood /w/ default-TLS fallback failed: %s'
                % dood_reason,
                log_utils.LOGWARNING
            )

        candidates = self._resolve_alias_candidates(url)
        if len(candidates) > 1:
            log_utils.log(
                '[PlaybackResolve] candidates=%s'
                % str(candidates),
                log_utils.LOGINFO
            )

        for candidate in candidates:
            attempted = candidate
            try:
                hmf = resolver.HostedMediaFile(
                    url=candidate,
                    include_disabled=True,
                    include_universal=False,
                    include_popups=allow_popups
                )
                if not hmf.valid_url():
                    last_reason = 'no_resolver'
                    continue

                resolved = hmf.resolve()
                if resolved in (False, None, ''):
                    last_reason = 'resolver_returned_empty'
                    continue

                resolved = str(resolved)

                # Some hoster resolvers hand back another hoster page. One
                # additional hop is allowed; after that it is rejected.
                if self._looks_like_hoster_page(resolved):
                    try:
                        hmf2 = resolver.HostedMediaFile(
                            url=resolved,
                            include_disabled=True,
                            include_universal=False,
                            include_popups=True
                        )
                        if hmf2.valid_url():
                            resolved2 = hmf2.resolve()
                            if resolved2 not in (False, None, ''):
                                resolved = str(resolved2)
                    except Exception:
                        pass

                if self._looks_like_hoster_page(resolved):
                    last_reason = 'resolver_returned_hoster_page'
                    continue

                return resolved, 'ok', candidate

            except Exception as exc:
                last_reason = 'resolver_exception:%s' % str(exc)

        if is_dood:
            dood_url, dood_reason = self._resolve_dood_default_tls(url)
            if dood_url:
                return dood_url, 'ok', str(url)
            if dood_reason:
                last_reason = dood_reason

        # Generic last resort for a new hoster: one normal HTML request and
        # extraction of an already exposed HLS/MP4 URL. No JS execution and no
        # anti-bot bypass. This handles the recurring class of "new hoster,
        # same simple player layout" without waiting for a dedicated resolver.
        if last_reason in ('no_resolver', 'resolver_returned_empty', 'resolver_returned_hoster_page'):
            generic_url, generic_reason = hotfix.generic_extract(url)
            if generic_url:
                log_utils.log(
                    '[SelfHeal] Generic hoster extraction OK | input=%s | final=%s'
                    % (str(url), str(generic_url)),
                    log_utils.LOGWARNING
                )
                return generic_url, 'ok', str(url)
            if generic_reason:
                last_reason = '%s|%s' % (last_reason, generic_reason)

        return None, last_reason, attempted

    def _hls_first_segment_preflight(self, resolved_url, timeout=5):
        """Quickly verify that the first real HLS segment starts responding.

        Which provider/hoster pairs need this is data-driven by hotfix_rules.json.
        The probe itself remains generic and never hard-codes a CDN hostname.
        """
        started = time.time()
        text_url = str(resolved_url or '')
        manifest_url, sep, pipe = text_url.partition('|')
        if not manifest_url.lower().startswith(('http://', 'https://')):
            return False, 'invalid_manifest_url'

        headers = {}
        if sep and pipe:
            for part in pipe.split('&'):
                if '=' not in part:
                    continue
                key, value = part.split('=', 1)
                try:
                    key = unquote_plus(key)
                    value = unquote_plus(value)
                except Exception:
                    pass
                if key:
                    headers[key] = value

        # ResolveURL normally supplies these. Keep sane defaults only as a
        # guard for a future resolver version that omits one of them.
        headers.setdefault(
            'User-Agent',
            'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/148.0.7778.216 Mobile Safari/537.36'
        )
        headers.setdefault('Referer', 'https://firestream.to/')
        headers.setdefault('Origin', 'https://firestream.to')
        headers.setdefault(
            'Accept',
            'application/vnd.apple.mpegurl,application/x-mpegURL,*/*'
        )

        def _inherit_query(base, ref):
            absolute = urljoin(base, ref.strip())
            try:
                base_parts = urlparse(base)
                out_parts = urlparse(absolute)
                if (
                    not out_parts.query and base_parts.query and
                    out_parts.netloc == base_parts.netloc
                ):
                    absolute = urlunparse(
                        out_parts._replace(query=base_parts.query)
                    )
            except Exception:
                pass
            return absolute

        try:
            current_url = manifest_url
            segment_url = None

            # A Firestream URL can be either a media playlist directly or a
            # master playlist pointing to one more .m3u8. Two descents cover
            # both layouts without turning this into a full HLS implementation.
            for _depth in range(3):
                req = Request(current_url, headers=headers)
                response = build_opener().open(req, timeout=timeout)
                status = getattr(response, 'status', None) or response.getcode()
                if status and int(status) >= 400:
                    return False, 'manifest_http_%s' % status

                payload = response.read(256 * 1024).decode('utf-8', 'ignore')
                lines = [line.strip() for line in payload.splitlines() if line.strip()]
                refs = [line for line in lines if not line.startswith('#')]
                if not refs:
                    return False, 'manifest_no_media_ref'

                # In a master playlist the first non-comment URI following an
                # EXT-X-STREAM-INF is a child playlist. In a media playlist the
                # first non-comment URI is already a segment.
                first_ref = refs[0]
                target_url = _inherit_query(current_url, first_ref)
                target_path = urlparse(target_url).path.lower()
                is_child_playlist = target_path.endswith('.m3u8')

                if is_child_playlist and _depth < 2:
                    current_url = target_url
                    continue

                segment_url = target_url
                break

            if not segment_url:
                return False, 'manifest_no_segment'

            segment_headers = dict(headers)
            # We only need proof that the CDN starts serving the real segment;
            # do not download the whole HLS chunk during preflight.
            segment_headers['Range'] = 'bytes=0-65535'
            seg_request = Request(segment_url, headers=segment_headers)
            seg_response = build_opener().open(seg_request, timeout=timeout)
            seg_status = getattr(seg_response, 'status', None) or seg_response.getcode()
            if seg_status and int(seg_status) >= 400:
                return False, 'segment_http_%s' % seg_status
            first_byte = seg_response.read(1)
            if not first_byte:
                return False, 'segment_empty'

            log_utils.log(
                '[SelfHeal] HLS preflight OK '
                '| %.2fs | cdn=%s | segment=%s'
                % (
                    time.time() - started,
                    str(urlparse(segment_url).hostname or ''),
                    str(segment_url)
                ),
                log_utils.LOGWARNING
            )
            return True, 'ok'

        except Exception as exc:
            reason = '%s:%s' % (exc.__class__.__name__, str(exc))
            log_utils.log(
                '[SelfHeal] HLS preflight FAIL '
                '| %.2fs | reason=%s | manifest=%s'
                % (time.time() - started, reason, manifest_url),
                log_utils.LOGWARNING
            )
            return False, reason

    def sourcesResolve(self, item, info=False):
        self.url = None

        provider = str(item.get('provider', ''))
        hoster = str(item.get('source', ''))
        quality = str(item.get('quality', ''))
        direct = item.get('direct') is True
        local = item.get('local', False)
        original_url = item.get('url')

        log_utils.log(
            '[PlaybackResolve] START provider=%s | hoster=%s | quality=%s | '
            'direct=%s | input=%s'
            % (
                provider, hoster, quality, str(direct), str(original_url)
            ),
            log_utils.LOGWARNING
        )

        try:
            call = [i[1] for i in self.sourceDict if i[0] == provider][0]

            try:
                url = call.resolve(original_url)
            except Exception as exc:
                log_utils.log(
                    '[PlaybackResolve] FAIL provider=%s | hoster=%s | '
                    'quality=%s | reason=provider_resolve_exception:%s | '
                    'input=%s'
                    % (
                        provider, hoster, quality, str(exc),
                        str(original_url)
                    ),
                    log_utils.LOGERROR
                )
                if info:
                    self.errorForSources()
                return

            if url in (False, None, ''):
                hotfix.record_resolve(provider, hoster, False, 'provider_returned_empty')
                log_utils.log(
                    '[PlaybackResolve] FAIL provider=%s | hoster=%s | '
                    'quality=%s | reason=provider_returned_empty | input=%s'
                    % (
                        provider, hoster, quality, str(original_url)
                    ),
                    log_utils.LOGERROR
                )
                if info:
                    self.errorForSources()
                return

            log_utils.log(
                '[PlaybackResolve] PROVIDER provider=%s | hoster=%s | '
                'quality=%s | result=%s'
                % (
                    provider, hoster, quality, str(url)
                ),
                log_utils.LOGINFO
            )

            if local:
                self.url = url
                log_utils.log(
                    '[PlaybackResolve] OK provider=%s | hoster=%s | '
                    'quality=%s | mode=local | final=%s'
                    % (provider, hoster, quality, str(url)),
                    log_utils.LOGWARNING
                )
                return url

            text_url = str(url)
            if '://' not in text_url:
                log_utils.log(
                    '[PlaybackResolve] FAIL provider=%s | hoster=%s | '
                    'quality=%s | reason=no_url_scheme | result=%s'
                    % (provider, hoster, quality, text_url),
                    log_utils.LOGERROR
                )
                if info:
                    self.errorForSources()
                return

            # Media file / adaptive manifest: safe to send directly to Kodi.
            if self._is_direct_media_url(text_url):
                final_url = text_url
                resolved_mode = 'direct-media'

            elif not direct:
                # Critical 12.9 fix: if ResolveURL does not know the URL, the
                # raw webpage is discarded instead of falling through to Kodi.
                final_url, reason, attempted = self._resolve_with_resolveurl(
                    text_url,
                    allow_popups=(item.get('prioHoster', 0) >= 999)
                )
                resolved_mode = 'resolveurl'

                # Only retry with popup-capable resolvers if the first pass
                # failed because no resolver matched at all. If a real resolver
                # already ran and returned an HTTP/Cloudflare/Video-not-found
                # error, repeating the same network work only doubles the wait.
                retry_reasons = {
                    'no_resolver',
                    'resolver_returned_empty',
                }
                if (
                    not final_url and
                    item.get('prioHoster', 0) < 999 and
                    reason in retry_reasons
                ):
                    final_url, reason2, attempted2 = self._resolve_with_resolveurl(
                        text_url,
                        allow_popups=True
                    )
                    if final_url:
                        reason = 'ok'
                        attempted = attempted2
                    else:
                        reason = reason2 or reason
                        attempted = attempted2 or attempted

                if not final_url and reason not in retry_reasons:
                    log_utils.log(
                        '[PlaybackResolve] NO-RETRY provider=%s | hoster=%s | '
                        'quality=%s | reason=%s'
                        % (provider, hoster, quality, reason),
                        log_utils.LOGWARNING
                    )

                if not final_url:
                    hotfix.record_resolve(provider, hoster, False, reason)
                    log_utils.log(
                        '[PlaybackResolve] FAIL provider=%s | hoster=%s | '
                        'quality=%s | reason=%s | indirect_url=%s | '
                        'attempted=%s'
                        % (
                            provider, hoster, quality, reason,
                            text_url, attempted
                        ),
                        log_utils.LOGERROR
                    )
                    if info:
                        self.errorForSources()
                    return

            else:
                # A provider may say direct=True even though an earlier
                # pre-resolve returned another hoster page. That was the path
                # which allowed dood.yt/w/... to reach Kodi in the supplied log.
                if self._looks_like_hoster_page(text_url):
                    final_url, reason, attempted = self._resolve_with_resolveurl(
                        text_url,
                        allow_popups=True
                    )
                    resolved_mode = 'direct-hoster-reresolve'

                    if not final_url:
                        log_utils.log(
                            '[PlaybackResolve] FAIL provider=%s | hoster=%s | '
                            'quality=%s | reason=%s | '
                            'direct_but_hoster_page=%s | attempted=%s'
                            % (
                                provider, hoster, quality, reason,
                                text_url, attempted
                            ),
                            log_utils.LOGERROR
                        )
                        if info:
                            self.errorForSources()
                        return
                else:
                    final_url = text_url
                    resolved_mode = 'provider-direct'

            # Final invariant: a known hoster webpage never reaches Kodi.
            if self._looks_like_hoster_page(final_url):
                hotfix.record_resolve(provider, hoster, False, 'final_is_hoster_page')
                log_utils.log(
                    '[PlaybackResolve] FAIL provider=%s | hoster=%s | '
                    'quality=%s | reason=final_is_hoster_page | final=%s'
                    % (
                        provider, hoster, quality, str(final_url)
                    ),
                    log_utils.LOGERROR
                )
                if info:
                    self.errorForSources()
                return

            # Data-driven playback preflight. Current rules contain the known
            # Movie2k2->Firestream case, but future provider/hoster pairs can be
            # added in hotfix_rules.json without touching this resolver code.
            preflight = hotfix.preflight_rule(provider, hoster, final_url)
            if preflight and preflight.get('type') == 'hls_first_segment':
                try:
                    _pf_timeout = int(preflight.get('timeout', 5))
                except Exception:
                    _pf_timeout = 5
                preflight_ok, preflight_reason = self._hls_first_segment_preflight(
                    final_url, timeout=_pf_timeout
                )
                if not preflight_ok:
                    hotfix.record_resolve(provider, hoster, False, 'preflight:%s' % preflight_reason)
                    log_utils.log(
                        '[PlaybackResolve] FAIL provider=%s | hoster=%s | '
                        'quality=%s | reason=selfheal_preflight:%s:%s | final=%s'
                        % (
                            provider, hoster, quality,
                            str(preflight.get('id', 'rule')),
                            preflight_reason, str(final_url)
                        ),
                        log_utils.LOGERROR
                    )
                    if info:
                        self.errorForSources()
                    return

            hotfix.record_resolve(provider, hoster, True, resolved_mode)
            self.url = final_url
            log_utils.log(
                '[PlaybackResolve] OK provider=%s | hoster=%s | '
                'quality=%s | mode=%s | final=%s'
                % (
                    provider, hoster, quality,
                    resolved_mode, str(final_url)
                ),
                log_utils.LOGWARNING
            )
            return final_url

        except Exception as exc:
            log_utils.log(
                '[PlaybackResolve] FAIL provider=%s | hoster=%s | '
                'quality=%s | reason=unexpected:%s | input=%s'
                % (
                    provider, hoster, quality,
                    str(exc), str(original_url)
                ),
                log_utils.LOGERROR
            )
            if info:
                self.errorForSources()
            return


    def sourcesDialog(self, items):
        labels = [i['label'] for i in items]

        select = control.selectDialog(labels)
        if select == -1: return 'close://'

        next = [y for x,y in enumerate(items) if x >= select]
        prev = [y for x,y in enumerate(items) if x < select][::-1]

        items = [items[select]]
        items = [i for i in items+next+prev][:40]

        header = control.addonInfo('name')
        header2 = header.upper()

        progressDialog = control.progressDialog if control.getSetting('progress.dialog') == '0' else control.progressDialogBG
        progressDialog.create(header, '')
        progressDialog.update(0)

        block = None

        try:
            for i in range(len(items)):
                try:
                    if items[i]['source'] == block: raise Exception()

                    future = self.executor.submit(self.sourcesResolve, items[i])

                    try:
                        if progressDialog.iscanceled(): break
                        progressDialog.update(int((100 / float(len(items))) * i), str(items[i]['label']))
                    except:
                        progressDialog.update(int((100 / float(len(items))) * i), str(header2) + str(items[i]['label']))

                    waiting_time = 30
                    while waiting_time > 0:
                        try:
                            if control.abortRequested: return sys.exit() #xbmc.Monitor().abortRequested()
                            if progressDialog.iscanceled(): return progressDialog.close()
                        except:
                            pass

                        if future.done(): break
                        control.sleep(1)

                        waiting_time = waiting_time - 1

                        if control.condVisibility('Window.IsActive(virtualkeyboard)') or \
                                control.condVisibility('Window.IsActive(yesnoDialog)') or \
                                control.condVisibility('Window.IsActive(ProgressDialog)'):
                            waiting_time = waiting_time + 1 #dont count down while dialog is presented ## control.condVisibility('Window.IsActive(PopupRecapInfoWindow)') or \

                    if not future.done(): block = items[i]['source']

                    if self.url == None: raise Exception()

                    self.selectedSource = items[i]['label']

                    try: progressDialog.close()
                    except: pass

                    control.execute('Dialog.Close(virtualkeyboard)')
                    control.execute('Dialog.Close(yesnoDialog)')
                    return self.url
                except:
                    pass

            try: progressDialog.close()
            except: pass

        except Exception as e:
            try: progressDialog.close()
            except: pass
            log_utils.log('Error %s' % str(e), log_utils.LOGINFO)


    def sourcesDirect(self, items):
        # TODO - OK
        # filter = [i for i in items if i['source'].lower() in self.hostcapDict and i['debrid'] == '']
        # items = [i for i in items if not i in filter]
        # items = [i for i in items if ('autoplay' in i and i['autoplay'] == True) or not 'autoplay' in i]

        u = None

        header = control.addonInfo('name')
        header2 = header.upper()

        try:
            control.sleep(1)

            progressDialog = control.progressDialog if control.getSetting('progress.dialog') == '0' else control.progressDialogBG
            progressDialog.create(header, '')
            progressDialog.update(0)
        except:
            pass

        for i in range(len(items)):
            try:
                if progressDialog.iscanceled(): break
                progressDialog.update(int((100 / float(len(items))) * i), str(items[i]['label']))
            except:
                progressDialog.update(int((100 / float(len(items))) * i), str(header2) + str(items[i]['label']))

            try:
                if control.abortRequested: return sys.exit()

                url = self.sourcesResolve(items[i])
                if u == None: u = url
                if not url == None: break
            except:
                pass

        try: progressDialog.close()
        except: pass

        return u

    def mediaInfo(self, source, dialog=None):
        import xbmcgui
        try:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        except: pass
        try:
            item = json.loads(source)[0]
            if item['source'] is None:
                raise Exception()

            import time as _time
            from resources.lib.mediainfo import TOTAL_TIMEOUT
            deadline = _time.time() + TOTAL_TIMEOUT

            if dialog is None:
                dialog = xbmcgui.DialogProgress()
                dialog.create('Medien-Info', 'Löse Stream-URL auf...')
                dialog.update(0)

            future = self.executor.submit(self.sourcesResolve, item)

            # Wait for resolve with responsive cancel (check every 250ms)
            # Cap at deadline so resolve + probe share the TOTAL_TIMEOUT budget
            for i in range(120):  # 120 * 250ms = 30s max
                remaining = int(deadline - _time.time())
                if remaining <= 0:
                    break
                dialog.update(int(50.0 * i / 120), 'Löse Stream-URL auf...')
                try:
                    if dialog.iscanceled():
                        try: dialog.close()
                        except: pass
                        return
                except: pass
                if future.done():
                    break
                control.sleep(0.25)  # 250ms — control.sleep() takes seconds, not ms
                # Don't count down while resolver shows interactive dialogs
                if control.condVisibility('Window.IsActive(virtualkeyboard)') or \
                        control.condVisibility('Window.IsActive(yesnoDialog)'):
                    continue

            url = self.url if future.done() else None
            control.execute('Dialog.Close(virtualkeyboard)')
            control.execute('Dialog.Close(yesnoDialog)')

            try:
                if dialog.iscanceled():
                    try: dialog.close()
                    except: pass
                    return
            except: pass

            if url is None:
                try: dialog.close()
                except: pass
                control.infoDialog("Stream-URL konnte nicht aufgelöst werden", sound=False, icon='INFO')
                return

            log_utils.log('mediaInfo: resolve done, url=%s deadline_remaining=%.1f' % (url[:80], deadline - _time.time()), log_utils.LOGWARNING)
            dialog.update(50, 'Analysiere Stream...')

            from resources.lib import mediainfo
            t_probe = _time.time()
            info = mediainfo.getMediaInfo(url, dialog, deadline)
            log_utils.log('mediaInfo: probe done in %.1fs, got_info=%s' % (_time.time() - t_probe, bool(info)), log_utils.LOGWARNING)

            try: dialog.close()
            except: pass

            if info:
                xbmcgui.Dialog().textviewer('Medien-Info', info)
            else:
                control.infoDialog("Auflösung konnte nicht ermittelt werden", sound=False, icon='INFO')

        except Exception as e:
            try:
                if dialog: dialog.close()
            except: pass
            log_utils.log('mediaInfo Error: %s' % str(e), log_utils.LOGERROR)
            control.infoDialog("Auflösung konnte nicht ermittelt werden", sound=False, icon='INFO')


    def errorForSources(self):
        control.infoDialog("Keine Streams verfügbar oder ausgewählt", sound=False, icon='INFO')

    def getTitle(self, title):
        title = utils.normalize(title)
        return title

    def getConstants(self):
        self.itemsProperty = '%s.container.items' % control.Addon.getAddonInfo('id')
        self.metaProperty = '%s.container.meta'  % control.Addon.getAddonInfo('id')
        from scrapers import sources
        self.sourceDict = sources()
