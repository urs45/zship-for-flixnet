# -*- coding: UTF-8 -*-
"""zShip declarative hotfix + self-healing engine.

The important design rule is that remotely/local-updated hotfix files contain
DATA ONLY.  They can select already shipped strategies, regexes, timeouts and
policies, but they can never execute Python.  This allows zShip to react to
small provider changes without turning the hotfix channel into arbitrary code
execution.
"""
import json
import os
import re
import threading
import time
from urllib.parse import urljoin, urlparse, quote_plus
from urllib.request import Request, build_opener

from resources.lib import control, log_utils

_LOCK = threading.RLock()
_TLS = threading.local()
_CACHE = {'mtime': None, 'rules': None, 'checked_remote': 0.0}

_BUNDLED = os.path.join(control.addonPath, 'resources', 'data', 'hotfix_rules.json')
_PROFILE = os.path.join(control.addonProfilePath, 'hotfix_rules.json')
_STATE = os.path.join(control.addonProfilePath, 'hotfix_state.json')
_CANDIDATES = os.path.join(control.addonProfilePath, 'hotfix_candidates.json')


def _read_json(path, default=None):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else (default or {})
    except Exception:
        return default or {}


def _atomic_json(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=True)
        os.replace(tmp, path)
        return True
    except Exception as exc:
        log_utils.log('[SelfHeal] JSON write failed %s: %s' % (path, str(exc)), log_utils.LOGWARNING)
        return False


def _revision(data):
    try:
        return int((data or {}).get('revision', 0))
    except Exception:
        return 0


def bootstrap():
    """Ensure a writable profile hotfix exists and prefer the newest revision."""
    if control.getSetting('selfheal.enabled', 'true') == 'false':
        return
    with _LOCK:
        bundled = _read_json(_BUNDLED, {})
        profile = _read_json(_PROFILE, {})
        if bundled.get('schema') != 1:
            return
        if not profile or _revision(bundled) > _revision(profile):
            if _atomic_json(_PROFILE, bundled):
                log_utils.log(
                    '[SelfHeal] hotfix profile updated to revision=%s' % _revision(bundled),
                    log_utils.LOGINFO
                )
        _CACHE['mtime'] = None
        _CACHE['rules'] = None
    maybe_refresh_remote(force=True)
    try:
        _reconcile_candidates()
    except Exception:
        pass


def maybe_refresh_remote(force=False):
    """Optionally refresh rules from an HTTPS JSON feed.

    The URL is intentionally user/config supplied.  We do not ship a magic
    server endpoint.  Only schema-1 JSON with a newer revision is accepted.
    """
    if control.getSetting('selfheal.enabled', 'true') == 'false':
        return False
    try:
        from resources.lib import update_channel
        url = update_channel.hotfix_url()
    except Exception:
        url = str(control.getSetting('selfheal.remote_url', '') or '').strip()
    if not url:
        return False
    if not url.lower().startswith('https://'):
        log_utils.log('[SelfHeal] remote hotfix ignored: HTTPS required', log_utils.LOGWARNING)
        return False

    now = time.time()
    try:
        interval_min = max(5, int(control.getSetting('selfheal.remote_interval', '30') or 30))
    except Exception:
        interval_min = 30
    with _LOCK:
        state = _load_state()
        persisted_last = float((state.get('meta') or {}).get('remote_checked', 0) or 0)
        memory_last = float(_CACHE.get('checked_remote') or 0)
        last_check = max(persisted_last, memory_last)
        if not force and now - last_check < interval_min * 60:
            return False
        _CACHE['checked_remote'] = now
        state['meta']['remote_checked'] = int(now)
        _save_state(state)

    try:
        req = Request(url, headers={
            'User-Agent': 'zShip-SelfHeal/1',
            'Accept': 'application/json'
        })
        response = build_opener().open(req, timeout=6)
        raw = response.read(256 * 1024)
        data = json.loads(raw.decode('utf-8', 'replace'))
        if not isinstance(data, dict) or data.get('schema') != 1:
            raise ValueError('unsupported schema')
        current = rules(refresh_remote=False)
        if _revision(data) <= _revision(current):
            return False
        if _atomic_json(_PROFILE, data):
            with _LOCK:
                _CACHE['mtime'] = None
                _CACHE['rules'] = None
            log_utils.log(
                '[SelfHeal] remote hotfix applied revision=%s' % _revision(data),
                log_utils.LOGWARNING
            )
            try:
                _reconcile_candidates()
            except Exception:
                pass
            return True
    except Exception as exc:
        log_utils.log('[SelfHeal] remote refresh failed: %s' % str(exc), log_utils.LOGINFO)
    return False


def rules(refresh_remote=True):
    if control.getSetting('selfheal.enabled', 'true') == 'false':
        return {}
    if refresh_remote:
        maybe_refresh_remote(force=False)
    path = _PROFILE if os.path.exists(_PROFILE) else _BUNDLED
    try:
        mtime = os.path.getmtime(path)
    except Exception:
        mtime = None
    with _LOCK:
        if _CACHE.get('rules') is not None and _CACHE.get('mtime') == mtime:
            return _CACHE['rules']
        data = _read_json(path, {})
        if data.get('schema') != 1:
            data = _read_json(_BUNDLED, {})
        _CACHE['rules'] = data
        _CACHE['mtime'] = mtime
        return data


def provider_config(provider):
    return dict((rules().get('providers') or {}).get(str(provider or '').lower()) or {})


def _load_state():
    data = _read_json(_STATE, {})
    if not isinstance(data, dict):
        data = {}
    data.setdefault('strategies', {})
    data.setdefault('providers', {})
    data.setdefault('pairs', {})
    data.setdefault('meta', {})
    return data


def _save_state(data):
    return _atomic_json(_STATE, data)



def _load_candidates():
    data = _read_json(_CANDIDATES, {})
    if not isinstance(data, dict):
        data = {}
    data.setdefault('schema', 1)
    data.setdefault('updated', 0)
    data.setdefault('candidates', {})
    return data


def _save_candidates(data):
    data['schema'] = 1
    data['updated'] = int(time.time())
    return _atomic_json(_CANDIDATES, data)


def candidate_notifications_enabled():
    # Deliberately defaults to OFF. Admin/test boxes can opt in while normal
    # family/friend installations still learn silently in the background.
    return control.getSetting('selfheal.candidate_notify', 'false') == 'true'


def _candidate_detection_config():
    cfg = ((rules(refresh_remote=False).get('resolver') or {}).get('candidate_detection') or {})
    try:
        min_alt = max(1, int(cfg.get('min_alternative_success_streak', 3)))
    except Exception:
        min_alt = 3
    try:
        recent_hours = max(1, int(cfg.get('recent_hours', 24)))
    except Exception:
        recent_hours = 24
    return {
        'enabled': cfg.get('enabled', True) is not False,
        'min_alternative_success_streak': min_alt,
        'recent_seconds': recent_hours * 3600,
    }


def _upsert_candidate(key, payload, notification=''):
    """Persist a local general-hotfix candidate and optionally notify once.

    Candidate collection is independent from notifications. This is important:
    quiet installations still build the diagnostic evidence, but only admin/test
    boxes with selfheal.candidate_notify=true show a Kodi popup.
    """
    now = int(time.time())
    with _LOCK:
        data = _load_candidates()
        table = data['candidates']
        existing = dict(table.get(key) or {})
        first_seen = int(existing.get('first_seen', 0) or now)
        last_notified_signature = str(existing.get('last_notified_signature') or '')
        row = dict(existing)
        row.update(payload or {})
        row['key'] = key
        row['active'] = True
        row['first_seen'] = first_seen
        row['last_seen'] = now
        signature = str(row.get('signature') or key)
        row['signature'] = signature
        table[key] = row
        _save_candidates(data)

    if notification and candidate_notifications_enabled() and last_notified_signature != signature:
        try:
            control.infoDialog(
                notification[:260],
                heading='zShip Self-Healing',
                icon='WARNING', time=10000, sound=False
            )
            with _LOCK:
                data = _load_candidates()
                current = data['candidates'].get(key) or {}
                current['last_notified_signature'] = signature
                current['last_notified'] = int(time.time())
                data['candidates'][key] = current
                _save_candidates(data)
        except Exception:
            pass


def _deactivate_candidate(key, reason='central_rule_matches'):
    with _LOCK:
        data = _load_candidates()
        row = data.get('candidates', {}).get(key)
        if not isinstance(row, dict) or not row.get('active'):
            return
        row['active'] = False
        row['resolved_at'] = int(time.time())
        row['resolved_reason'] = str(reason or '')[:120]
        data['candidates'][key] = row
        _save_candidates(data)


def _evaluate_strategy_candidate(provider, feature):
    cfg = _candidate_detection_config()
    if not cfg['enabled']:
        return
    p = str(provider or '').lower()
    feature = str(feature or '')
    configured = (provider_config(p).get(feature) or [])
    configured = [x for x in configured if isinstance(x, dict) and x.get('id')]
    if len(configured) < 2:
        return
    central_id = str(configured[0].get('id'))
    state = _load_state()
    learned = (state.get('strategies', {}).get('%s:%s' % (p, feature)) or {})
    central = learned.get(central_id, {}) or {}
    central_last_failure = int(central.get('last_failure', 0) or 0)
    central_last_success = int(central.get('last_success', 0) or 0)
    key = 'strategy:%s:%s' % (p, feature)

    # The centrally configured primary works again: the local deviation no
    # longer needs a general hotfix.
    if central_last_success >= central_last_failure and central_last_success:
        _deactivate_candidate(key, 'central_strategy_recovered')
        return
    if not central_last_failure:
        return
    if time.time() - central_last_failure > cfg['recent_seconds']:
        return

    best_id = ''
    best_row = None
    for item in configured[1:]:
        sid = str(item.get('id'))
        row = learned.get(sid, {}) or {}
        streak = int(row.get('success_streak', 0) or 0)
        last_success = int(row.get('last_success', 0) or 0)
        if streak < cfg['min_alternative_success_streak']:
            continue
        if last_success < central_last_failure:
            continue
        if best_row is None or (streak, last_success) > (
            int(best_row.get('success_streak', 0) or 0),
            int(best_row.get('last_success', 0) or 0),
        ):
            best_id, best_row = sid, row
    if not best_row:
        return

    streak = int(best_row.get('success_streak', 0) or 0)
    signature = '%s>%s' % (central_id, best_id)
    _upsert_candidate(
        key,
        {
            'type': 'strategy_deviation',
            'provider': p,
            'feature': feature,
            'central_strategy': central_id,
            'working_strategy': best_id,
            'central_last_failure': central_last_failure,
            'central_failures': int(central.get('failures', 0) or 0),
            'working_success_streak': streak,
            'working_successes': int(best_row.get('successes', 0) or 0),
            'signature': signature,
        },
        '%s nutzt stabil %s statt der zentralen Regel %s. Zentraler Hotfix empfohlen.'
        % (p, best_id, central_id)
    )


def _register_auto_lazy_candidate(provider, elapsed, eager):
    p = str(provider or '').lower()
    if not p:
        return
    # If the current declarative rules already request lazy resolve, it is not
    # a local deviation and therefore not a candidate.
    if provider_config(p).get('force_lazy_resolve') is True:
        _deactivate_candidate('auto_lazy:%s' % p, 'already_in_central_rules')
        return
    _upsert_candidate(
        'auto_lazy:%s' % p,
        {
            'type': 'auto_lazy',
            'provider': p,
            'elapsed': round(float(elapsed or 0), 3),
            'eager_resolves': int(eager or 0),
            'signature': 'auto_lazy:%s' % p,
        },
        '%s wurde lokal automatisch auf Lazy-Resolve umgestellt. Zentraler Hotfix empfohlen.' % p
    )


def _reconcile_candidates():
    """Mark candidates resolved once a newer central rule incorporates them."""
    with _LOCK:
        data = _load_candidates()
        items = list((data.get('candidates') or {}).items())
    for key, row in items:
        if not isinstance(row, dict) or not row.get('active'):
            continue
        kind = row.get('type')
        provider = str(row.get('provider') or '').lower()
        if kind == 'auto_lazy':
            if provider_config(provider).get('force_lazy_resolve') is True:
                _deactivate_candidate(key, 'central_hotfix_applied')
        elif kind == 'strategy_deviation':
            feature = str(row.get('feature') or '')
            configured = provider_config(provider).get(feature) or []
            first = next((x for x in configured if isinstance(x, dict) and x.get('id')), None)
            if first and str(first.get('id')) == str(row.get('working_strategy') or ''):
                _deactivate_candidate(key, 'central_hotfix_applied')


def candidate_rows(active_only=True):
    data = _load_candidates()
    rows = []
    for row in (data.get('candidates') or {}).values():
        if not isinstance(row, dict):
            continue
        if active_only and not row.get('active'):
            continue
        rows.append(dict(row))
    rows.sort(key=lambda x: int(x.get('last_seen', 0) or 0), reverse=True)
    return rows


def candidates_text():
    rows = candidate_rows(active_only=True)
    if not rows:
        return 'Keine aktiven Hotfix-Kandidaten erkannt.'
    out = ['Aktive lokale Hotfix-Kandidaten:']
    for row in rows:
        if row.get('type') == 'strategy_deviation':
            out.append(
                '\n%s / %s\nZentral: %s\nLokal stabil: %s\nErfolgsserie: %s'
                % (
                    row.get('provider', '?'), row.get('feature', '?'),
                    row.get('central_strategy', '?'), row.get('working_strategy', '?'),
                    row.get('working_success_streak', 0)
                )
            )
        elif row.get('type') == 'auto_lazy':
            out.append(
                '\n%s\nAutomatisch auf Lazy-Resolve umgestellt\nLetzter langsamer Lauf: %.1fs / %s Eager-Resolves'
                % (
                    row.get('provider', '?'), float(row.get('elapsed', 0) or 0),
                    row.get('eager_resolves', 0)
                )
            )
        else:
            out.append('\n%s' % str(row))
    return '\n'.join(out)

def begin_provider_run(provider):
    _TLS.provider = str(provider or '').lower()
    _TLS.eager_resolves = 0


def current_provider():
    return str(getattr(_TLS, 'provider', '') or '')


def note_eager_resolve(provider=None):
    p = str(provider or current_provider() or '').lower()
    if not p:
        return
    if p == current_provider():
        _TLS.eager_resolves = int(getattr(_TLS, 'eager_resolves', 0) or 0) + 1


def should_force_lazy(provider=None):
    if control.getSetting('selfheal.enabled', 'true') == 'false':
        return False
    p = str(provider or current_provider() or '').lower()
    if not p:
        return False
    cfg = provider_config(p)
    if cfg.get('force_lazy_resolve') is True:
        return True
    with _LOCK:
        state = _load_state()
        return bool((state.get('providers', {}).get(p) or {}).get('force_lazy_resolve'))


def finish_provider_run(provider, elapsed, raw_count=0):
    """Learn the recurring slow-provider/eager-resolve pattern."""
    p = str(provider or '').lower()
    eager = int(getattr(_TLS, 'eager_resolves', 0) or 0) if p == current_provider() else 0
    try:
        _TLS.provider = ''
        _TLS.eager_resolves = 0
    except Exception:
        pass
    cfg = (rules().get('resolver') or {}).get('auto_lazy') or {}
    if not cfg.get('enabled', True) or not p:
        return
    try:
        slow = float(cfg.get('slow_seconds', 8.0))
        min_calls = int(cfg.get('min_eager_calls', 2))
    except Exception:
        slow, min_calls = 8.0, 2
    if float(elapsed or 0) < slow or eager < min_calls:
        return
    with _LOCK:
        state = _load_state()
        entry = state['providers'].setdefault(p, {})
        entry['last_elapsed'] = round(float(elapsed or 0), 3)
        entry['last_eager_resolves'] = eager
        entry['last_raw_count'] = int(raw_count or 0)
        entry['last_run'] = int(time.time())
        entry['force_lazy_resolve'] = True
        _save_state(state)
    log_utils.log(
        '[SelfHeal] AUTO-LAZY provider=%s elapsed=%.2fs eager_resolves=%d'
        % (p, float(elapsed or 0), eager),
        log_utils.LOGWARNING
    )
    _register_auto_lazy_candidate(p, elapsed, eager)


def ordered_strategies(provider, feature, defaults=None):
    p = str(provider or '').lower()
    cfg = provider_config(p)
    configured = cfg.get(feature)
    strategies = configured if isinstance(configured, list) else (defaults or [])
    strategies = [dict(x) for x in strategies if isinstance(x, dict) and x.get('id')]
    with _LOCK:
        state = _load_state()
        learned = state.get('strategies', {}).get('%s:%s' % (p, feature), {})
    indexed = list(enumerate(strategies))
    def _key(pair):
        idx, item = pair
        row = learned.get(item.get('id'), {})
        score = int(row.get('score', 0) or 0)
        last_ok = int(row.get('last_success', 0) or 0)
        # Strongly favor a strategy that actually worked, but retain configured
        # order as the stable tie breaker.
        return (-score, -last_ok, idx)
    return [item for _, item in sorted(indexed, key=_key)]


def record_strategy(provider, feature, strategy_id, success, status=None, reason=''):
    if not strategy_id:
        return
    key = '%s:%s' % (str(provider or '').lower(), feature)
    now = int(time.time())
    with _LOCK:
        state = _load_state()
        table = state['strategies'].setdefault(key, {})
        row = table.setdefault(str(strategy_id), {})
        score = int(row.get('score', 0) or 0)
        if success:
            row['score'] = min(50, score + 6)
            row['successes'] = int(row.get('successes', 0) or 0) + 1
            row['success_streak'] = int(row.get('success_streak', 0) or 0) + 1
            row['failure_streak'] = 0
            row['last_success'] = now
        else:
            row['score'] = max(-50, score - 2)
            row['failures'] = int(row.get('failures', 0) or 0) + 1
            row['failure_streak'] = int(row.get('failure_streak', 0) or 0) + 1
            row['success_streak'] = 0
            row['last_failure'] = now
        if status is not None:
            row['last_status'] = str(status)
        if reason:
            row['last_reason'] = str(reason)[:240]
        _save_state(state)
    _evaluate_strategy_candidate(provider, feature)


def record_resolve(provider, hoster, success, reason=''):
    p = str(provider or '').lower()
    h = str(hoster or '').lower()
    if not p or not h:
        return
    key = '%s|%s' % (p, h)
    now = int(time.time())
    with _LOCK:
        state = _load_state()
        row = state['pairs'].setdefault(key, {})
        if success:
            row['score'] = min(20, int(row.get('score', 0) or 0) + 3)
            row['last_success'] = now
        else:
            row['score'] = max(-20, int(row.get('score', 0) or 0) - 2)
            row['last_failure'] = now
            row['last_reason'] = str(reason or '')[:240]
        _save_state(state)


def pair_penalty(provider, hoster):
    key = '%s|%s' % (str(provider or '').lower(), str(hoster or '').lower())
    with _LOCK:
        row = _load_state().get('pairs', {}).get(key, {})
    score = int(row.get('score', 0) or 0)
    last_failure = int(row.get('last_failure', 0) or 0)
    last_success = int(row.get('last_success', 0) or 0)
    # Only a recent unresolved failure affects ordering. This prevents a one-off
    # outage from condemning a provider/hoster pair forever.
    if last_success >= last_failure:
        return 0
    if last_failure and time.time() - last_failure > 6 * 60 * 60:
        return 0
    # Positive number means push later. Never fully hide a source.
    return max(0, -score)


def preflight_rule(provider, hoster, url=''):
    p = str(provider or '').lower()
    h = str(hoster or '').lower()
    u = str(url or '').lower()
    rows = ((rules().get('resolver') or {}).get('preflight_rules') or [])
    for row in rows:
        if not isinstance(row, dict):
            continue
        if row.get('provider') and str(row.get('provider')).lower() != p:
            continue
        needle = str(row.get('hoster_contains') or '').lower()
        if needle and needle not in h:
            continue
        url_needle = str(row.get('url_contains') or '').lower()
        if url_needle and url_needle not in u:
            continue
        return dict(row)
    return None


def extraction_patterns(provider, key, defaults=None):
    cfg = provider_config(provider)
    extract = cfg.get('extract') or {}
    pats = extract.get(key)
    if isinstance(pats, list) and pats:
        return [str(x) for x in pats if x]
    return list(defaults or [])


def first_match(text, patterns, flags=re.I | re.S):
    source = str(text or '')
    for pattern in patterns or []:
        try:
            m = re.search(pattern, source, flags)
            if m:
                return (m.group(1) if m.lastindex else m.group(0)).strip()
        except Exception:
            continue
    return ''


def generic_extract(url, user_agent=None):
    """Conservative, one-page fallback for a new/unknown hoster.

    It does not execute JS or bypass anti-bot. It only recognizes already
    exposed direct HLS/MP4 URLs, which covers a surprisingly common class of
    new hosters without a dedicated ResolveURL plugin.
    """
    cfg = (rules().get('resolver') or {}).get('generic_extract') or {}
    if not cfg.get('enabled', True):
        return None, 'generic_extract_disabled'
    text_url = str(url or '').split('|', 1)[0].strip()
    if not text_url.lower().startswith(('http://', 'https://')):
        return None, 'generic_extract_bad_url'
    try:
        timeout = int(cfg.get('timeout', 6))
        max_bytes = int(cfg.get('max_bytes', 524288))
    except Exception:
        timeout, max_bytes = 6, 524288
    headers = {
        'User-Agent': user_agent or 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 Chrome/148.0 Mobile Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Referer': text_url,
    }
    try:
        response = build_opener().open(Request(text_url, headers=headers), timeout=timeout)
        final_url = str(getattr(response, 'url', '') or text_url)
        if re.search(r'\.(?:m3u8|mp4)(?:\?|$)', urlparse(final_url).path + ('?' + urlparse(final_url).query if urlparse(final_url).query else ''), re.I):
            return final_url, 'generic_redirect_media'
        html = response.read(max_bytes).decode('utf-8', 'ignore')
        patterns = cfg.get('patterns') or []
        found = []
        for pattern in patterns:
            try:
                for m in re.finditer(str(pattern), html, re.I | re.S):
                    value = (m.group(1) if m.lastindex else m.group(0)).strip().replace('\\/', '/')
                    absolute = urljoin(final_url, value)
                    if re.search(r'\.(?:m3u8|mp4)(?:\?|$)', absolute, re.I):
                        found.append(absolute)
            except Exception:
                continue
        if found:
            found.sort(key=lambda x: ('.m3u8' not in x.lower(), len(x)))
            media = found[0]
            pipe = 'User-Agent=%s&Referer=%s' % (quote_plus(headers['User-Agent']), quote_plus(final_url))
            return media + '|' + pipe, 'generic_html_media'
        return None, 'generic_no_media'
    except Exception as exc:
        return None, 'generic_exception:%s' % str(exc)
