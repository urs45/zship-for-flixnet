# zShip provider loader - full xShip compatibility port 2026-09-07
import importlib.util
import os
from resources.lib import log_utils

try:
    import xbmcaddon
    __addon__ = xbmcaddon.Addon()
except Exception:
    __addon__ = None

debug = True
_SCRAPERS_ROOT = os.path.dirname(__file__)
_ADDON_ROOT = os.path.dirname(_SCRAPERS_ROOT)
_SITES_FOLDER = os.path.join(_ADDON_ROOT, 'sites')
_LEGACY_FOLDER = os.path.join(_SCRAPERS_ROOT, 'scrapers_source', 'de')


def _folder_has_providers(folder):
    if not os.path.isdir(folder):
        return False
    return any(f.endswith('.py') and not f.startswith('__') for f in os.listdir(folder))


def getActiveProviderFolder():
    return _SITES_FOLDER if _folder_has_providers(_SITES_FOLDER) else _LEGACY_FOLDER


def getProviderModuleNames():
    folder = getActiveProviderFolder()
    if not os.path.isdir(folder):
        return []
    return sorted(f[:-3] for f in os.listdir(folder) if f.endswith('.py') and not f.startswith('__'))


def enabledCheck(module_name):
    # Important: zShip's old .check/health state can be stale or false because many
    # current sites reject HTTP HEAD. The actual scraper request decides whether a
    # provider works. Only respect the user's visible provider switch here.
    if __addon__ is None:
        return True
    return __addon__.getSetting('provider.' + module_name) != 'false'


def _load_provider(module_name, folder):
    path = os.path.join(folder, module_name + '.py')
    # Unique module name avoids Kodi/Python keeping an old provider module in sys.modules.
    spec = importlib.util.spec_from_file_location('zship_provider_' + module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError('No import spec for %s' % module_name)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not hasattr(module, 'source'):
        raise ImportError('%s has no source class' % module_name)
    return module.source()


def sources(specified_folders=None):
    source_dict = []
    folder = getActiveProviderFolder()
    for module_name in getProviderModuleNames():
        if not enabledCheck(module_name):
            continue
        try:
            source_dict.append((module_name, _load_provider(module_name, folder)))
        except Exception as e:
            # Do NOT flip the setting to false. Log the actual error for diagnosis.
            if debug:
                log_utils.log('Provider load failed: %s: %s' % (module_name, e), log_utils.LOGERROR)
    return source_dict


def providerSources():
    return ['Sites']


def providerNames():
    return [name.split('_')[0] for name in getProviderModuleNames()]


def getAllHosters():
    return list(set(providerNames()))


def getScraperFolder(scraper_source):
    return os.path.basename(getActiveProviderFolder())


def getModuleName(scraper_folders):
    return providerSources()
