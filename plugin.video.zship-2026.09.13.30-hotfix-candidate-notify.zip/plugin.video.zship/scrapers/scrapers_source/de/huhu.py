# huhu
# edit 2026-08-01

import json
from urllib.parse import urlparse
from resources.lib.utils import isBlockedHoster
from resources.lib.control import getSetting
from resources.lib.requestHandler import cRequestHandler
from resources.lib.utils import getExtIDS

SITE_IDENTIFIER = 'huhu'
SITE_DOMAIN = 'www.huhu.to'
SITE_NAME = SITE_IDENTIFIER.upper()


def _is_doodstream(url, info=''):
    """Return True for DoodStream/Dood hoster URLs without resolving them.

    DoodStream often fails during background/pre-resolve even though ResolveURL
    can resolve it successfully when the user selects the source.
    """
    try:
        host = (urlparse(str(url)).hostname or '').lower()
    except Exception:
        host = ''
    text = ('%s %s' % (host, info or '')).lower()
    return 'dood' in text or 'doood' in text

class source:
    def __init__(self):
        self.priority = getSetting('provider.' + SITE_IDENTIFIER + '.priority', 100) # je kleiner der Wert um so höher die Priorität
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain+ '/'

    def run(self, titles, year, season=0, episode=0, imdb=''):
        sources = []
        ids = getExtIDS(imdb, season)   # trakt.tv season=0 movie result else shows result
        id = ids['tmdb']

        mediatype = 'series'
        if season == 0: mediatype = 'movie'
        data = {
            'language': 'de', 'region': 'DE',
            'type': mediatype, 'ids': {'tmdb_id': id}, 'name': ''
        }
        if mediatype == 'series':
            data['episode'] = {'ids': {}, 'season': season, 'episode': episode}

        oRequest = cRequestHandler(self.base_link + 'mediaurl-source.json', caching=False, ignoreErrors=True, method='POST', data=json.dumps(data))
        oRequest.addHeaderEntry('Content-Type', 'application/json; charset=utf-8')
        oRequest.addHeaderEntry('Referer', self.base_link)
        oRequest.removeNewLines(False)
        response = oRequest.request()
        data = json.loads(response)

        data = [i for i in data if i['languages']==['de']]
        for i in data:
            try:
                url = i['url']
                if 'filemoon' in url: continue
                language = i.get('languages', ['de'])[0]
                quality = i.get('tag', '720p')
                info = i.get('name', '')
                # DoodStream must not be fully resolved during discovery.
                # It can fail in a background ResolveURL pass even though it
                # resolves correctly when the user selects the source. Keep the
                # original hoster URL and defer only DoodStream to playback.
                if _is_doodstream(url, info):
                    isBlocked, hoster, _checkedUrl, prioHoster = isBlockedHoster(url, isResolve=False)
                    if isBlocked:
                        continue
                    hoster = 'DoodStream'
                    sUrl = url
                    direct = False
                else:
                    isBlocked, hoster, sUrl, prioHoster = isBlockedHoster(url)
                    if isBlocked:
                        continue
                    direct = True
                sources.append({'source': hoster, 'quality': quality, 'language': language, 'url': sUrl, 'info': info, 'direct': direct, 'priority': int(self.priority), 'prioHoster': prioHoster})
            except:
                pass
        return sources

    def resolve(self, url):
        return url
