# -*- coding: utf-8 -*-
# TopStreamFilm current zShip provider
# 2026-09-12.7

import html
import re
import unicodedata
from urllib.parse import quote_plus, urljoin, urlparse

from resources.lib.control import getSetting
from resources.lib.requestHandler import cRequestHandler
from resources.lib.utils import isBlockedHoster
from resources.lib import log_utils

SITE_IDENTIFIER = 'topstreamfilm'
SITE_DOMAIN = 'www.topstreamfilm.live'
SITE_NAME = 'TOPSTREAMFILM'


class source:
    def __init__(self):
        self.priority = int(getSetting(
            'provider.' + SITE_IDENTIFIER + '.priority', 100
        ))
        self.language = ['de']
        self.domain = getSetting(
            'provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN
        ) or SITE_DOMAIN
        self.base_link = 'https://' + self.domain
        self.sources = []

    def _get(self, url, caching=True):
        try:
            req = cRequestHandler(url, caching=caching, ignoreErrors=True)
            req.addHeaderEntry('Referer', self.base_link + '/')
            req.cacheTime = 60 * 60 * 6
            content = req.request() or ''
            if 'CLOUDFLARE-SCHUTZ AKTIV' in content:
                return ''
            return content
        except Exception as exc:
            log_utils.log(
                '[TOPSTREAMFILM] Request fehlgeschlagen: %s | %s'
                % (url, str(exc)),
                log_utils.LOGWARNING
            )
            return ''

    @staticmethod
    def _clean(text):
        text = html.unescape(str(text or '')).lower()
        text = unicodedata.normalize('NFKD', text)
        text = ''.join(ch for ch in text if not unicodedata.combining(ch))
        text = text.replace('ß', 'ss')
        text = re.sub(
            r'\b(?:derfilm|film|stream|online|kostenlos|deutsch)\b',
            '',
            text
        )
        return re.sub(r'[^a-z0-9]', '', text)

    @staticmethod
    def _quality(text):
        t = str(text or '').upper()
        if '2160' in t or '4K' in t:
            return '4K'
        if '1080' in t:
            return '1080p'
        if '720' in t or t == 'HD':
            return '720p'
        if '480' in t:
            return '480p'
        if 'CAM' in t or re.search(r'\bTS\b', t):
            return 'CAM'
        return 'HD'

    def _abs(self, value):
        value = html.unescape(str(value or '')).strip()
        if not value:
            return ''
        if value.startswith('//'):
            return 'https:' + value
        return urljoin(self.base_link + '/', value)

    def _extract_internal_candidates(self, page, title, year, season=0):
        target = self._clean(title)
        if not target:
            return []

        allowed_years = set()
        if year:
            allowed_years = {
                str(year), str(int(year) - 1), str(int(year) + 1)
            }

        found = []
        seen = set()

        for m in re.finditer(
            r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>',
            page, re.I
        ):
            href = self._abs(m.group(1))
            parsed = urlparse(href)
            if not parsed.hostname:
                continue
            if parsed.hostname.lower().lstrip('www.') != self.domain.lower().lstrip('www.'):
                continue
            if not any(x in parsed.path.lower() for x in (
                '/kostenlos/', '/film/', '/filme/', '/serien/', '/serie/'
            )):
                continue

            left = max(0, m.start() - 1000)
            right = min(len(page), m.end() + 2200)
            ctx_html = page[left:right]
            ctx_text = re.sub(r'<[^>]+>', ' ', ctx_html)
            ctx_clean = self._clean(ctx_text)

            if target not in ctx_clean and ctx_clean not in target:
                continue

            if not season and allowed_years:
                context_years = set(
                    re.findall(r'\b(?:19|20)\d{2}\b', ctx_text)
                )
                if context_years and not (context_years & allowed_years):
                    continue

            if href not in seen:
                seen.add(href)
                found.append(href)

        return found

    def _find_page(self, titles, year, season=0):
        pages = []
        for title in titles or []:
            if not title:
                continue
            q = quote_plus(str(title))
            pages.extend([
                self.base_link + '/?story=%s&do=search&subaction=search' % q,
                self.base_link + '/?do=search&subaction=search&titleonly=3&story=%s' % q,
            ])

            for search_url in pages[-2:]:
                search_html = self._get(search_url, caching=False)
                candidates = self._extract_internal_candidates(
                    search_html, title, year, season
                )
                if candidates:
                    log_utils.log(
                        '[TOPSTREAMFILM] Treffer via Suche: %s'
                        % candidates[0],
                        log_utils.LOGINFO
                    )
                    return candidates[0]

        # Current site search can occasionally return a protection/empty page
        # while category pages remain reachable. Cheap bounded fallback only.
        fallback_pages = (
            [self.base_link + '/serien/']
            if int(season or 0) > 0
            else [
                self.base_link + '/beliebte-filme-online.html',
                self.base_link + '/filme-online-sehen/',
            ]
        )

        for browse_url in fallback_pages:
            browse_html = self._get(browse_url)
            for title in titles or []:
                if not title:
                    continue
                candidates = self._extract_internal_candidates(
                    browse_html, title, year, season
                )
                if candidates:
                    log_utils.log(
                        '[TOPSTREAMFILM] Treffer via Fallback: %s'
                        % candidates[0],
                        log_utils.LOGINFO
                    )
                    return candidates[0]

        return ''

    def _collect_supported(self, base_url, page):
        quality = self._quality(page)
        result = []
        seen = set()

        def add(raw, forced_quality=None):
            raw = self._abs(raw) if not str(raw).startswith(('http://', 'https://', '//')) else str(raw)
            if raw.startswith('//'):
                raw = 'https:' + raw
            raw = html.unescape(raw).strip()
            if not raw.startswith(('http://', 'https://')):
                return

            host = (urlparse(raw).hostname or '').lower()
            if not host:
                return
            if host.lower().lstrip('www.') == self.domain.lower().lstrip('www.'):
                return
            if any(x in host for x in (
                'imdb.', 'themoviedb.', 'facebook.', 'twitter.',
                'instagram.', 'youtube.', 'google.'
            )):
                return
            if raw in seen:
                return

            blocked, hoster, checked, prio = isBlockedHoster(
                raw, isResolve=False, provider=SITE_IDENTIFIER
            )
            if blocked:
                return

            seen.add(raw)
            low = raw.split('?', 1)[0].lower()
            direct = low.endswith(('.m3u8', '.mp4', '.mpd'))
            result.append({
                'source': hoster or host,
                'quality': forced_quality or quality or 'HD',
                'language': 'de',
                'url': checked or raw,
                'direct': direct,
                'priority': self.priority,
                'prioHoster': prio,
            })

        # First inspect embedded/player iframes because current TSF often keeps
        # its data-link mirrors there.
        iframe_urls = []
        for raw in re.findall(
            r'<iframe[^>]+src=["\']([^"\']+)["\']',
            page, re.I
        ):
            full = self._abs(raw)
            if full and full not in iframe_urls:
                iframe_urls.append(full)

        for iframe_url in iframe_urls[:4]:
            iframe_host = (urlparse(iframe_url).hostname or '').lower()
            # If the iframe itself is a ResolveURL hoster, keep it.
            add(iframe_url)

            # Also inspect the iframe HTML for its mirror list.
            iframe_html = self._get(iframe_url, caching=False)
            if iframe_html:
                for pattern in (
                    r'data-link=["\']([^"\']+)["\']',
                    r'data-player-url=["\']([^"\']+)["\']',
                    r'href=["\']([^"\']+)["\']',
                ):
                    for raw in re.findall(pattern, iframe_html, re.I):
                        add(raw)

        # Direct links on the title page.
        for pattern in (
            r'data-link=["\']([^"\']+)["\']',
            r'data-player-url=["\']([^"\']+)["\']',
            r'href=["\']([^"\']+)["\']',
        ):
            for raw in re.findall(pattern, page, re.I):
                add(raw)

        return result

    def _serial_episode(self, imdb, season, episode):
        if not imdb:
            return []

        imdb_num = re.sub(r'[^0-9]', '', str(imdb))
        pages = [
            self._get(
                'https://meinecloud.click/serial/%s' % imdb_num,
                caching=False
            ),
            self._get(
                'https://meinecloud.click/serial/%s' % imdb,
                caching=False
            ),
        ]
        page = next((p for p in pages if p), '')
        if not page:
            return []

        sid_to_snum = {}
        for sid, label in re.findall(
            r'data-season=["\'](\d+)["\'][^>]*>\s*(S\d+)\s*<',
            page, re.I
        ):
            m = re.match(r'S(\d+)', label.strip(), re.I)
            if m:
                sid_to_snum[sid] = int(m.group(1))

        result = []
        blocks = re.split(
            r'(?=<div[^>]*class=["\'][^"\']*_season-eps[^"\']*["\'][^>]*data-season=["\'])',
            page
        )

        for block in blocks:
            sid_m = re.match(
                r'<div[^>]*data-season=["\'](\d+)["\']', block, re.I
            )
            if not sid_m:
                continue
            if sid_to_snum.get(sid_m.group(1)) != int(season):
                continue

            links = re.findall(
                r'data-link=["\']([^"\']+)["\']', block, re.I
            )
            labels = re.findall(
                r'data-label=["\']([^"\']+)["\']', block, re.I
            )
            nums = re.findall(
                r'<div[^>]*class=["\'][^"\']*_ep-n[^"\']*["\'][^>]*>(\d+)</div>',
                block, re.I
            )

            for i, raw in enumerate(links):
                ep_num = int(nums[i]) if i < len(nums) else i + 1
                if ep_num != int(episode):
                    continue
                if raw.startswith('//'):
                    raw = 'https:' + raw
                label = labels[i] if i < len(labels) else ''
                q = self._quality(label)
                blocked, hoster, checked, prio = isBlockedHoster(
                    raw, isResolve=False
                )
                if not blocked:
                    result.append({
                        'source': hoster or (urlparse(raw).hostname or SITE_NAME),
                        'quality': q,
                        'language': 'de',
                        'url': checked or raw,
                        'direct': False,
                        'priority': self.priority,
                        'prioHoster': prio,
                    })
        return result

    def _movie_cloud_fallback(self, imdb):
        if not imdb:
            return []
        result = []
        seen = set()
        for url in (
            'https://meinecloud.click/movie/%s' % imdb,
            'https://meinecloud.click/ddl/%s' % imdb,
        ):
            page = self._get(url, caching=False)
            if not page:
                continue
            candidates = re.findall(
                r'(?:data-link|href)=["\'](https?://[^"\']+)["\']',
                page, re.I
            )
            candidates += [
                x[0] for x in re.findall(
                    r"window\.open.*?'([^']+).*?mark>([^<]+)",
                    page, re.S | re.I
                )
            ]

            for raw in candidates:
                raw = html.unescape(raw).strip()
                if raw in seen:
                    continue
                blocked, hoster, checked, prio = isBlockedHoster(
                    raw, isResolve=False
                )
                if blocked:
                    continue
                seen.add(raw)
                result.append({
                    'source': hoster or (urlparse(raw).hostname or SITE_NAME),
                    'quality': 'HD',
                    'language': 'de',
                    'url': checked or raw,
                    'direct': False,
                    'priority': self.priority,
                    'prioHoster': prio,
                })
        return result

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []

        if int(season or 0) > 0 and imdb:
            self.sources = self._serial_episode(imdb, season, episode)
            if self.sources:
                log_utils.log(
                    '[TOPSTREAMFILM] Serienquellen: %d'
                    % len(self.sources),
                    log_utils.LOGINFO
                )
                return self.sources

        page_url = self._find_page(titles, year, season)
        if page_url:
            page = self._get(page_url, caching=False)
            if page:
                self.sources = self._collect_supported(page_url, page)

        if not self.sources and int(season or 0) == 0:
            self.sources = self._movie_cloud_fallback(imdb)

        log_utils.log(
            '[TOPSTREAMFILM] Ergebnis: %d Quellen%s'
            % (
                len(self.sources),
                (' | page=' + page_url) if page_url else ''
            ),
            log_utils.LOGINFO
        )
        return self.sources

    def resolve(self, url):
        return url
