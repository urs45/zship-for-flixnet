# -*- coding: utf-8 -*-
# einschalten
# zShip playback-refresh port 2026-09-12.6

import json
import time
from urllib.parse import urlparse

from resources.lib.requestHandler import cRequestHandler
from resources.lib.utils import isBlockedHoster
from resources.lib.control import getSetting
from resources.lib import log_utils

SITE_IDENTIFIER = 'einschalten'
SITE_DOMAIN = 'einschalten.in'
SITE_NAME = SITE_IDENTIFIER.upper()


class source:
    def __init__(self):
        self.priority = int(getSetting(
            'provider.' + SITE_IDENTIFIER + '.priority', 100
        ))
        self.language = ['de']
        self.domain = getSetting(
            'provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN
        ) or SITE_DOMAIN
        self.base_link = 'https://' + self.domain
        self.sources = []

    def _watch(self, tmdb_id, force=False):
        url = self.base_link + '/api/movies/%s/watch' % str(tmdb_id)
        if force:
            url += '?_=%d' % int(time.time() * 1000)
        try:
            req = cRequestHandler(url, caching=not force, ignoreErrors=True)
            raw = req.request()
            if not raw or 'streamUrl' not in raw:
                return None
            data = json.loads(raw)
            return data if isinstance(data, dict) else None
        except Exception as exc:
            log_utils.log(
                '[EINSCHALTEN] watch Fehler: %s' % str(exc),
                log_utils.LOGWARNING
            )
            return None

    @staticmethod
    def _quality(release):
        text = str(release or '').lower()
        if '2160' in text or '4k' in text:
            return '4K'
        if '1080' in text:
            return '1080p'
        if '720' in text:
            return '720p'
        return 'HD'

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []

        tmdb_id = getattr(self, 'tmdb_id', None)
        if not tmdb_id:
            try:
                from resources.lib.utils import getExtIDS
                ids = getExtIDS(imdb, season)
                tmdb_id = ids.get('tmdb') if ids else None
            except Exception:
                tmdb_id = None

        if not tmdb_id:
            return self.sources

        data = self._watch(tmdb_id, force=False)
        if not data:
            return self.sources

        stream_url = str(data.get('streamUrl') or '').strip()
        if not stream_url:
            return self.sources

        quality = self._quality(data.get('releaseName'))
        blocked, hoster, checked, prio = isBlockedHoster(
            stream_url, isResolve=False, provider=SITE_IDENTIFIER
        )
        if blocked:
            hoster = urlparse(stream_url).hostname or SITE_NAME
            prio = 100

        # Stable token: the real short-lived/raw hoster URL is requested again
        # only when the user actually chooses this source.
        token = 'einschaltenrefresh://%s' % str(tmdb_id)
        self.sources.append({
            'source': hoster or SITE_NAME,
            'quality': quality,
            'language': 'de',
            'url': token,
            'direct': True,
            'priority': self.priority,
            'prioHoster': prio,
        })
        return self.sources

    def resolve(self, url):
        text = str(url or '')
        if not text.startswith('einschaltenrefresh://'):
            return text

        tmdb_id = text.split('://', 1)[1].strip()
        for attempt in (1, 2):
            data = self._watch(tmdb_id, force=True)
            if not data:
                continue

            stream_url = str(data.get('streamUrl') or '').strip()
            if not stream_url:
                continue

            # Direct media URLs bypass ResolveURL.
            low = stream_url.split('?', 1)[0].lower()
            if low.endswith(('.m3u8', '.mp4', '.mpd')):
                return stream_url

            blocked, hoster, resolved, prio = isBlockedHoster(
                stream_url, isResolve=True, provider=SITE_IDENTIFIER
            )
            if not blocked and resolved:
                return resolved

            log_utils.log(
                '[EINSCHALTEN] Playback-Resolve Versuch %d fehlgeschlagen: %s'
                % (attempt, hoster or stream_url),
                log_utils.LOGWARNING
            )
            time.sleep(0.35)

        return None
