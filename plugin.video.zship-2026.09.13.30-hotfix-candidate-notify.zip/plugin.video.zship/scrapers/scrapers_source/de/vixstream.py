# -*- coding: UTF-8 -*-
import base64
import json
import re
import time
import urllib.parse
from urllib.parse import urlparse

from resources.lib.requestHandler import cRequestHandler
from resources.lib.control import getSetting
from resources.lib.tools import logger
from resources.lib import hotfix

SITE_IDENTIFIER = 'vixstream'
SITE_DOMAIN = 'vixsrc.to'
SITE_NAME = SITE_IDENTIFIER.upper()
_K = base64.b64decode('ZWRkZTZiNWU0MTI0NmFiNzlhMjY5N2NkMTI1ZTE3ODE=').decode()


def _normalize_domain(value):
    raw = str(value or '').strip() or SITE_DOMAIN
    if '://' not in raw:
        raw = 'https://' + raw
    try:
        parsed = urlparse(raw)
        host = parsed.netloc or parsed.path
    except Exception:
        host = raw
    host = re.sub(r'^https?://', '', str(host), flags=re.I)
    return host.strip().strip('/').split('/')[0] or SITE_DOMAIN


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = _normalize_domain(
            getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        )
        self.base_link = 'https://' + self.domain
        self.tak = getSetting('api.tmdb') or _K
        self.ua = (
            "Mozilla/5.0 (Linux; Android 10; K) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36"
        )
        self.sources = []
        self._session = None

    def _get_session(self):
        if self._session is None:
            try:
                import requests
                self._session = requests.Session()
                self._session.headers.update({
                    'User-Agent': self.ua,
                    'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8'
                })
            except ImportError:
                logger.error('[%s] requests module nicht verfügbar!' % SITE_NAME)
        return self._session

    def _get_tmdb_id(self, imdb_id):
        try:
            url = (
                'https://api.themoviedb.org/3/find/%s'
                '?api_key=%s&external_source=imdb_id'
            ) % (imdb_id, self.tak)
            oRequest = cRequestHandler(url, caching=True)
            data = json.loads(oRequest.request())
            if data.get('movie_results'):
                return str(data['movie_results'][0]['id'])
            if data.get('tv_results'):
                return str(data['tv_results'][0]['id'])
        except Exception as e:
            logger.error('[%s] TMDB Fehler: %s' % (SITE_NAME, str(e)))
        return None

    def _api_url(self, tmdb_id, season=0, episode=0, lang='de'):
        if int(season or 0) == 0:
            return '%s/api/movie/%s?lang=%s' % (
                self.base_link, tmdb_id, lang
            )
        return '%s/api/tv/%s/%s/%s?lang=%s' % (
            self.base_link,
            tmdb_id,
            str(int(season or 0)),
            str(int(episode or 0)),
            lang
        )

    def _api_embed(self, tmdb_id, season=0, episode=0, lang='de'):
        session = self._get_session()
        if not session:
            return None

        api_url = self._api_url(tmdb_id, season, episode, lang)
        api_url += '&_=%d' % int(time.time() * 1000)
        headers = {
            'Referer': self.base_link + '/',
            'Origin': self.base_link,
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
        }

        try:
            response = session.get(
                api_url, headers=headers, timeout=10, allow_redirects=True
            )
            logger.info(
                '[%s] API besucht: %s - Status: %s'
                % (SITE_NAME, api_url.split('?')[0], response.status_code)
            )
            if response.status_code != 200:
                return None

            data = response.json()
            raw_src = str(data.get('src') or '').strip()
            if not raw_src:
                logger.warning('[%s] Kein src in API-Response' % SITE_NAME)
                return None

            parsed = urllib.parse.urlparse(raw_src)
            path = parsed.path or raw_src
            query = parsed.query
            if not path.startswith('/'):
                path = '/' + path
            embed_url = self.base_link + path
            if query:
                embed_url += '?' + query

            parts = urllib.parse.urlsplit(embed_url)
            qs = urllib.parse.parse_qs(parts.query, keep_blank_values=True)
            qs['lang'] = [lang]
            embed_url = urllib.parse.urlunsplit((
                parts.scheme,
                parts.netloc,
                parts.path,
                urllib.parse.urlencode(qs, doseq=True),
                parts.fragment
            ))

            logger.info(
                '[%s] Frischer VixSrc-Embed-Link geholt: tmdb=%s lang=%s'
                % (SITE_NAME, tmdb_id, lang)
            )
            return embed_url
        except Exception as e:
            logger.error('[%s] API Fehler: %s' % (SITE_NAME, str(e)))
            return None

    @staticmethod
    def _player_params(html):
        html = str(html or '')
        video_section = (
            html.split('window.video = {', 1)[1]
            if 'window.video = {' in html else html
        )
        playlist_section = (
            html.split('window.masterPlaylist', 1)[1]
            if 'window.masterPlaylist' in html else html
        )

        video_id = hotfix.first_match(
            video_section,
            hotfix.extraction_patterns(
                SITE_IDENTIFIER, 'video_id_patterns', [
                    r"\bid\s*:\s*['\"]?([^,'\"\s}]+)",
                    r"['\"]id['\"]\s*:\s*['\"]?([^,'\"\s}]+)",
                ]
            )
        )
        token = hotfix.first_match(
            playlist_section,
            hotfix.extraction_patterns(
                SITE_IDENTIFIER, 'token_patterns', [
                    r"['\"]?token['\"]?\s*:\s*['\"]([^'\"]+)",
                    r"\btoken\s*=\s*['\"]([^'\"]+)",
                ]
            )
        )
        expires = hotfix.first_match(
            playlist_section,
            hotfix.extraction_patterns(
                SITE_IDENTIFIER, 'expires_patterns', [
                    r"['\"]?expires['\"]?\s*:\s*['\"]([^'\"]+)",
                    r"\bexpires\s*=\s*['\"]([^'\"]+)",
                ]
            )
        )
        playlist = hotfix.first_match(
            playlist_section,
            hotfix.extraction_patterns(
                SITE_IDENTIFIER, 'playlist_patterns', [
                    r"\burl\s*:\s*['\"]([^'\"]+)",
                    r"['\"]url['\"]\s*:\s*['\"]([^'\"]+)",
                ]
            )
        ).replace('\\/', '/')

        return video_id, token, expires, playlist

    def _cookie_header(self):
        try:
            cookies = self._get_session().cookies.get_dict()
            return '; '.join('%s=%s' % (k, v) for k, v in cookies.items())
        except Exception:
            return ''

    def _resolve_current(self, tmdb_id, season=0, episode=0):
        session = self._get_session()
        if not session:
            return None

        for lang in ('de', 'en'):
            for attempt in (1, 2):
                embed_url = self._api_embed(
                    tmdb_id, season, episode, lang=lang
                )
                if not embed_url:
                    break

                headers = {
                    'Referer': self.base_link + '/',
                    'Origin': self.base_link,
                    'Accept': (
                        'text/html,application/xhtml+xml,application/xml;q=0.9,'
                        '*/*;q=0.8'
                    ),
                }

                try:
                    response = session.get(
                        embed_url,
                        headers=headers,
                        timeout=15,
                        allow_redirects=True
                    )
                except Exception as e:
                    logger.error(
                        '[%s] Embed Request Fehler: %s'
                        % (SITE_NAME, str(e))
                    )
                    break

                logger.info(
                    '[%s] VixSrc-Embed Status: %s'
                    % (SITE_NAME, response.status_code)
                )

                if response.status_code == 410 and attempt == 1:
                    logger.info(
                        '[%s] Embed 410 -> API einmal frisch nachladen.'
                        % SITE_NAME
                    )
                    continue
                if response.status_code != 200:
                    break

                html = response.text or ''
                video_id, token, expires, playlist_raw = self._player_params(html)

                if not (video_id and token and expires):
                    logger.warning(
                        '[%s] Player-Parameter fehlen: id=%s token=%s expires=%s'
                        % (
                            SITE_NAME,
                            'ja' if video_id else 'nein',
                            'ja' if token else 'nein',
                            'ja' if expires else 'nein'
                        )
                    )
                    break

                # Seit 13.09. akzeptiert VixSrc den historisch von zShip
                # rekonstruierten /playlist/<id>?lang=...&b=... Pfad nicht mehr
                # verlaesslich. Die Embed-Seite liefert inzwischen die kanonische
                # Master-URL selbst in window.masterPlaylist.url. Diese URL ist
                # deshalb die primaere Quelle; wir ergaenzen nur die signierten
                # token/expires-Werte und FHD, wie es der aktuelle Web-Player tut.
                api_referer = self._api_url(
                    tmdb_id, season, episode, lang=lang
                )

                direct_url = ''
                if playlist_raw:
                    direct_url = urllib.parse.urljoin(
                        self.base_link + '/', playlist_raw
                    )
                    parts = urllib.parse.urlsplit(direct_url)
                    qs = urllib.parse.parse_qsl(
                        parts.query, keep_blank_values=True
                    )
                    keys = {k for k, _ in qs}
                    if 'token' not in keys:
                        qs.append(('token', token))
                    if 'expires' not in keys:
                        qs.append(('expires', expires))
                    if (
                        re.search(r'window\.canPlayFHD\s*=\s*true', html, re.I)
                        and 'h' not in keys
                    ):
                        qs.append(('h', '1'))
                    direct_url = urllib.parse.urlunsplit((
                        parts.scheme, parts.netloc, parts.path,
                        urllib.parse.urlencode(qs), parts.fragment
                    ))

                legacy_params = [
                    ('token', token),
                    ('expires', expires),
                    ('lang', lang),
                ]
                if 'b=1' in html:
                    legacy_params.append(('b', '1'))
                if re.search(
                    r'window\.canPlayFHD\s*=\s*true', html, re.I
                ):
                    legacy_params.append(('h', '1'))
                legacy_url = '%s/playlist/%s?%s' % (
                    self.base_link, video_id,
                    urllib.parse.urlencode(legacy_params)
                )

                logger.info(
                    '[%s] VixSrc-Playlist Params id=%s lang=%s token=%s '
                    'expires=%s master_raw=%s direct=%s embed=%s'
                    % (
                        SITE_NAME, video_id, lang, token, expires,
                        playlist_raw or '(fehlt)', direct_url or '(fehlt)',
                        embed_url
                    )
                )

                cookie_header = self._cookie_header()

                # SelfHeal owns the strategy matrix and learns which variant
                # actually works. If VixSrc flips referer/origin expectations,
                # the next successful fallback is automatically promoted to
                # first place for subsequent plays.
                default_strategies = [
                    {'id': 'master-api-xhr-origin', 'url': 'master', 'referer': 'api', 'origin': 'root', 'accept': 'xhr'},
                    {'id': 'master-embed-hls-origin', 'url': 'master', 'referer': 'embed', 'origin': 'root', 'accept': 'hls'},
                    {'id': 'legacy-root-hls-origin', 'url': 'legacy', 'referer': 'root', 'origin': 'root', 'accept': 'hls'},
                ]
                strategy_rows = hotfix.ordered_strategies(
                    SITE_IDENTIFIER, 'playlist_strategies', default_strategies
                )

                candidates = []
                for strategy in strategy_rows:
                    url_kind = str(strategy.get('url', 'master'))
                    candidate_url = direct_url if url_kind == 'master' else legacy_url
                    if not candidate_url:
                        continue

                    referer_kind = str(strategy.get('referer', 'root'))
                    referers = {
                        'api': api_referer,
                        'embed': embed_url,
                        'root': self.base_link + '/',
                    }
                    accept_kind = str(strategy.get('accept', 'hls'))
                    accepts = {
                        'xhr': 'application/json, text/javascript, */*; q=0.01',
                        'hls': 'application/vnd.apple.mpegurl,application/x-mpegURL,application/octet-stream,*/*',
                        'html': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    }
                    h = {
                        'User-Agent': self.ua,
                        'Referer': referers.get(referer_kind, self.base_link + '/'),
                        'Accept': accepts.get(accept_kind, accepts['hls']),
                        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
                    }
                    if str(strategy.get('origin', 'root')) != 'omit':
                        h['Origin'] = self.base_link
                    if strategy.get('xrw') is True:
                        h['X-Requested-With'] = 'XMLHttpRequest'
                    if strategy.get('sec_fetch') == 'cors':
                        h.update({
                            'Sec-Fetch-Dest': 'empty',
                            'Sec-Fetch-Mode': 'cors',
                            'Sec-Fetch-Site': 'same-origin',
                        })
                    if cookie_header:
                        h['Cookie'] = cookie_header
                    candidates.append((str(strategy.get('id')), candidate_url, h))

                status = None
                manifest = ''
                response_headers = {}
                response_body = ''
                response_url = ''
                request_headers = {}
                request_mode = ''
                playlist_url = ''

                for mode, candidate_url, candidate_headers in candidates:
                    request_mode = mode
                    playlist_url = candidate_url
                    request_headers = candidate_headers
                    response_headers = {}
                    response_body = ''
                    response_url = ''
                    try:
                        probe = session.get(
                            candidate_url,
                            headers=candidate_headers,
                            timeout=10,
                            allow_redirects=True
                        )
                        status = probe.status_code
                        response_url = str(getattr(probe, 'url', '') or '')
                        try:
                            response_headers = dict(probe.headers or {})
                        except Exception:
                            response_headers = {}
                        try:
                            response_body = re.sub(
                                r'\s+', ' ', (probe.text or '')[:800]
                            ).strip()
                        except Exception:
                            response_body = ''
                        if status == 200:
                            manifest = probe.text or ''
                        probe.close()
                    except Exception as e:
                        logger.warning(
                            '[%s] Playlist-Preflight Fehler mode=%s: %s'
                            % (SITE_NAME, mode, str(e))
                        )
                        status = None

                    logger.info(
                        '[%s] VixSrc-Playlist Preflight status=%s id=%s lang=%s '
                        'cookie=%s mode=%s referer=%s url=%s'
                        % (
                            SITE_NAME, str(status), video_id, lang,
                            'ja' if cookie_header else 'nein', mode,
                            candidate_headers.get('Referer', ''),
                            candidate_url
                        )
                    )
                    _strategy_ok = bool(status == 200 and '#EXTM3U' in manifest[:512])
                    hotfix.record_strategy(
                        SITE_IDENTIFIER, 'playlist_strategies', mode,
                        _strategy_ok, status=status,
                        reason='' if _strategy_ok else ('http_%s' % str(status))
                    )
                    if _strategy_ok:
                        logger.info(
                            '[%s] SelfHeal strategy learned/preferred: %s'
                            % (SITE_NAME, mode)
                        )
                        break
                    # 410 bekommt weiterhin den bestehenden Fresh-API-Retry.
                    if status == 410:
                        break

                if status != 200:
                    logger.info(
                        '[%s] VixSrc-Playlist 403DIAG mode=%s request_url=%s '
                        'response_url=%s request_headers=%s '
                        'response_headers=%s body=%s'
                        % (
                            SITE_NAME, request_mode, playlist_url,
                            response_url, repr(request_headers),
                            repr(response_headers), repr(response_body[:500])
                        )
                    )

                if status == 410 and attempt == 1:
                    logger.info(
                        '[%s] Playlist 410 -> API/Embed einmal frisch nachladen.'
                        % SITE_NAME
                    )
                    continue

                if status != 200 or '#EXTM3U' not in manifest[:512]:
                    break

                kodi_headers = {
                    'User-Agent': self.ua,
                    # Exact context of the strategy that actually returned 200.
                    'Referer': request_headers.get('Referer', api_referer),
                }
                if request_headers.get('Origin'):
                    kodi_headers['Origin'] = request_headers.get('Origin')
                if cookie_header:
                    kodi_headers['Cookie'] = cookie_header

                final_url = '%s|%s' % (
                    playlist_url,
                    urllib.parse.urlencode(kodi_headers)
                )
                logger.info(
                    '[%s] VixSrc Direct-Playlist OK: id=%s lang=%s'
                    % (SITE_NAME, video_id, lang)
                )
                return final_url

        return None

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        try:
            tmdb_id = self._get_tmdb_id(imdb)
            if not tmdb_id:
                logger.warning(
                    '[%s] Keine TMDB-ID gefunden für IMDB: %s'
                    % (SITE_NAME, imdb)
                )
                return self.sources

            embed_url = self._api_embed(
                tmdb_id, season, episode, lang='de'
            )
            if not embed_url:
                embed_url = self._api_embed(
                    tmdb_id, season, episode, lang='en'
                )
            if not embed_url:
                return self.sources

            stable = 'vixrefresh://%s/%s/%s' % (
                tmdb_id,
                str(int(season or 0)),
                str(int(episode or 0))
            )
            self.sources.append({
                'source': 'VixSrc',
                'quality': '1080p',
                'language': 'de',
                'url': stable,
                'direct': True
            })
            logger.info(
                '[%s] Quelle verfügbar: tmdb=%s; signierte VixSrc-Playlist '
                'wird erst beim Anklicken erzeugt.'
                % (SITE_NAME, tmdb_id)
            )
        except Exception as e:
            logger.error('[%s] run() Fehler: %s' % (SITE_NAME, str(e)))
            import traceback
            logger.debug(
                '[%s] Traceback: %s'
                % (SITE_NAME, traceback.format_exc())
            )
        return self.sources

    @staticmethod
    def _parse_refresh_url(url_data):
        m = re.match(
            r'^vixrefresh://([^/]+)/(\d+)/(\d+)$',
            str(url_data or '')
        )
        if not m:
            return None
        return m.group(1), int(m.group(2)), int(m.group(3))

    def resolve(self, url_data):
        try:
            refresh = self._parse_refresh_url(url_data)
            if refresh:
                tmdb_id, season, episode = refresh
                return self._resolve_current(
                    tmdb_id, season, episode
                )

            logger.error('[%s] Unbekanntes resolve-Format' % SITE_NAME)
            return None
        except Exception as e:
            logger.error('[%s] resolve() Fehler: %s' % (SITE_NAME, str(e)))
            import traceback
            logger.debug(
                '[%s] Traceback: %s'
                % (SITE_NAME, traceback.format_exc())
            )
            return None
