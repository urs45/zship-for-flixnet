# -*- coding: utf-8 -*-
# FilmPalast current-page zShip provider
# 2026-09-12.7

import html
import re
import unicodedata
from urllib.parse import quote, urljoin, urlparse

from resources.lib.control import getSetting
from resources.lib.requestHandler import cRequestHandler
from resources.lib.utils import isBlockedHoster
from resources.lib import log_utils

SITE_IDENTIFIER = 'filmpalast'
SITE_DOMAIN = 'filmpalast.to'
SITE_NAME = 'FILMPALAST'


class source:
    def __init__(self):
        self.priority = int(getSetting(
            'provider.' + SITE_IDENTIFIER + '.priority', 100
        ))
        self.language = ['de']
        self.domain = getSetting(
            'provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN
        ) or SITE_DOMAIN
        self.base_link = 'https://' + self.domain
        self.sources = []

    def _get(self, url, caching=True):
        try:
            req = cRequestHandler(url, caching=caching, ignoreErrors=True)
            req.addHeaderEntry('Referer', self.base_link + '/')
            req.cacheTime = 60 * 60 * 6
            return req.request() or ''
        except Exception as exc:
            log_utils.log(
                '[FILMPALAST] Request fehlgeschlagen: %s | %s'
                % (url, str(exc)),
                log_utils.LOGWARNING
            )
            return ''

    @staticmethod
    def _clean(text):
        text = html.unescape(str(text or '')).lower()
        text = unicodedata.normalize('NFKD', text)
        text = ''.join(ch for ch in text if not unicodedata.combining(ch))
        return re.sub(r'[^a-z0-9]', '', text)

    @staticmethod
    def _slug(text):
        text = html.unescape(str(text or '')).lower()
        text = unicodedata.normalize('NFKD', text)
        text = ''.join(ch for ch in text if not unicodedata.combining(ch))
        text = text.replace('ß', 'ss')
        text = re.sub(r'[^a-z0-9]+', '-', text).strip('-')
        return text

    @staticmethod
    def _quality(page):
        m = re.search(
            r'(2160p?|4K|1080p?|720p?|480p?|CAM|TS|TELESYNC|WEB|BLURAY)',
            page, re.I
        )
        if not m:
            return 'HD'
        q = m.group(1).upper()
        if '2160' in q or '4K' in q:
            return '4K'
        if '1080' in q:
            return '1080p'
        if '720' in q:
            return '720p'
        if '480' in q:
            return '480p'
        if 'CAM' in q or 'TS' in q or 'TELESYNC' in q:
            return 'CAM'
        return 'HD'

    def _looks_like_title_page(self, page, title, year=0):
        if not page:
            return False
        target = self._clean(title)
        stripped = re.sub(r'<[^>]+>', ' ', page)
        clean_page = self._clean(stripped[:25000])
        if target and target not in clean_page:
            return False
        if year:
            years = {str(year), str(int(year) - 1), str(int(year) + 1)}
            visible_years = set(re.findall(r'\b(?:19|20)\d{2}\b', stripped[:25000]))
            if visible_years and not (visible_years & years):
                return False
        return True

    def _find_page(self, titles, year, season=0, episode=0):
        # Current FilmPalast URLs are very predictable. Try direct slugs first;
        # this is much cheaper and more reliable than parsing the old search UI.
        for title in titles or []:
            if not title:
                continue
            slug = self._slug(title)
            candidates = []
            if int(season or 0) == 0:
                if year:
                    candidates.append(
                        self.base_link + '/stream/%s-%s' % (slug, year)
                    )
                candidates.append(self.base_link + '/stream/%s' % slug)
            else:
                candidates.extend([
                    self.base_link + '/stream/%s-s%02de%02d'
                    % (slug, int(season), int(episode)),
                    self.base_link + '/stream/%s-s%se%s'
                    % (slug, int(season), int(episode)),
                ])

            for candidate in candidates:
                page = self._get(candidate)
                if self._looks_like_title_page(page, title, year):
                    log_utils.log(
                        '[FILMPALAST] Seite direkt gefunden: %s' % candidate,
                        log_utils.LOGINFO
                    )
                    return candidate, page

        # Search fallback for punctuation/alternative slugs and series.
        for title in titles or []:
            if not title:
                continue
            query = self.base_link + '/search/title/' + quote(str(title))
            search_html = self._get(query, caching=False)
            if not search_html:
                continue

            target = self._clean(title)
            # Extract all internal /stream/ links and inspect local context.
            for m in re.finditer(
                r'href=["\']([^"\']*/stream/[^"\']+)["\']',
                search_html, re.I
            ):
                href = urljoin(self.base_link, html.unescape(m.group(1)))
                left = max(0, m.start() - 800)
                right = min(len(search_html), m.end() + 1600)
                ctx = re.sub(r'<[^>]+>', ' ', search_html[left:right])
                if target not in self._clean(ctx):
                    continue
                page = self._get(href)
                if self._looks_like_title_page(page, title, year):
                    log_utils.log(
                        '[FILMPALAST] Seite via Suche gefunden: %s' % href,
                        log_utils.LOGINFO
                    )
                    return href, page

        return '', ''

    def _native_hosters(self, page_url, page):
        quality = self._quality(page)
        result = []
        seen = set()

        # Current pages expose playable links directly as hrefs. Older builds
        # also used data-player-url / data-link. Accept all three.
        patterns = (
            r'data-player-url=["\']([^"\']+)["\']',
            r'data-link=["\']([^"\']+)["\']',
            r'href=["\']([^"\']+)["\']',
        )

        for pattern in patterns:
            for raw in re.findall(pattern, page, re.I):
                raw = html.unescape(str(raw or '')).strip()
                if raw.startswith('//'):
                    raw = 'https:' + raw
                elif raw.startswith('/'):
                    raw = urljoin(page_url, raw)

                if not raw.startswith(('http://', 'https://')):
                    continue

                host = (urlparse(raw).hostname or '').lower()
                if not host:
                    continue
                if host == self.domain.lower() or host.endswith('.filmpalast.to'):
                    continue
                if host.endswith('.filmpalast.la'):
                    continue
                if any(x in host for x in (
                    'imdb.', 'themoviedb.', 'facebook.', 'twitter.',
                    'instagram.', 'youtube.', 'google.'
                )):
                    continue
                if raw in seen:
                    continue

                blocked, resolved_host, checked, prio = isBlockedHoster(
                    raw, isResolve=False, provider=SITE_IDENTIFIER
                )
                if blocked:
                    continue

                seen.add(raw)
                low = raw.split('?', 1)[0].lower()
                direct = low.endswith(('.m3u8', '.mp4', '.mpd'))
                result.append({
                    'source': resolved_host or host,
                    'quality': quality,
                    'language': 'de',
                    'url': checked or raw,
                    'direct': direct,
                    'priority': self.priority,
                    'prioHoster': prio,
                })

        return result

    def _cloud_fallback(self, imdb):
        # Fallback only. FilmPalast currently has its own page-native hosters,
        # but this prevents "0 results" if its HTML hides them temporarily.
        if not imdb:
            return []
        urls = [
            'https://meinecloud.click/movie/%s' % imdb,
            'https://meinecloud.click/ddl/%s' % imdb,
        ]
        result = []
        seen = set()
        for url in urls:
            page = self._get(url, caching=False)
            if not page:
                continue

            candidates = re.findall(
                r'(?:data-link|href)=["\'](https?://[^"\']+)["\']',
                page, re.I
            )
            candidates += [
                x[0] for x in re.findall(
                    r"window\.open.*?'([^']+).*?mark>([^<]+)",
                    page, re.S | re.I
                )
            ]

            for raw in candidates:
                raw = html.unescape(raw).strip()
                if raw in seen:
                    continue
                blocked, hoster, checked, prio = isBlockedHoster(
                    raw, isResolve=False
                )
                if blocked:
                    continue
                seen.add(raw)
                result.append({
                    'source': hoster or (urlparse(raw).hostname or SITE_NAME),
                    'quality': 'HD',
                    'language': 'de',
                    'url': checked or raw,
                    'direct': False,
                    'priority': self.priority,
                    'prioHoster': prio,
                })
        return result

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []

        page_url, page = self._find_page(titles, year, season, episode)
        if page_url and page:
            self.sources = self._native_hosters(page_url, page)

        if not self.sources and int(season or 0) == 0:
            self.sources = self._cloud_fallback(imdb)

        log_utils.log(
            '[FILMPALAST] Ergebnis: %d Quellen%s'
            % (
                len(self.sources),
                (' | page=' + page_url) if page_url else ''
            ),
            log_utils.LOGINFO
        )
        return self.sources

    def resolve(self, url):
        return url
