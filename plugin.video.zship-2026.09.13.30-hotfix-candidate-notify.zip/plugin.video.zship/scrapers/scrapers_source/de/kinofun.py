# -*- coding: utf-8 -*-
# KinoFun (kinoger.fun) - new zShip provider
# Adapted from supplied MovieScout scraper 2026-09-12.6

import ast
import re
import requests
from urllib.parse import quote, urlparse

from resources.lib.control import getSetting
from resources.lib.utils import isBlockedHoster

SITE_IDENTIFIER = 'kinofun'
SITE_DOMAIN = 'kinoger.fun'
SITE_NAME = 'KINOFUN'

_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
)


class source:
    def __init__(self):
        self.priority = int(getSetting(
            'provider.' + SITE_IDENTIFIER + '.priority', 100
        ))
        self.language = ['de']
        self.domain = getSetting(
            'provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN
        ) or SITE_DOMAIN
        self.base_link = 'https://' + self.domain
        self.sources = []

    def _get(self, url, referer=None):
        try:
            r = requests.get(
                url,
                headers={
                    'User-Agent': _UA,
                    'Referer': referer or (self.base_link + '/')
                },
                timeout=10
            )
            r.raise_for_status()
            return r.text
        except Exception:
            return ''

    @staticmethod
    def _clean(text):
        return re.sub(r'[^a-z0-9]', '', str(text or '').lower())

    @staticmethod
    def _quality(label):
        t = str(label or '').upper()
        if '2160' in t or '4K' in t:
            return '4K'
        if '1080' in t or 'HD+' in t:
            return '1080p'
        if '720' in t or t == 'HD':
            return '720p'
        if '480' in t:
            return '480p'
        return 'HD'

    def _abs(self, url):
        if not url:
            return ''
        if url.startswith('http'):
            return url
        if url.startswith('//'):
            return 'https:' + url
        if url.startswith('/'):
            return self.base_link + url
        return self.base_link + '/' + url

    def _parse_entries(self, html, is_series_page=False):
        items = []
        pattern = (
            r'<div class="title">\s*<div class="begin"><img[^>]*/>\s*'
            r'<a href="([^"]+)">([^<]+)</a>'
            r'.*?<div class="content_text">.*?<img src="([^"]+)"'
        )
        for m in re.finditer(pattern, html, re.S | re.I):
            href = self._abs(m.group(1))
            name = m.group(2).strip()
            year_m = re.search(r'\((\d{4})\)\s*$', name)
            entry_year = year_m.group(1) if year_m else ''
            name_clean = re.sub(r'\s*\(\d{4}\)\s*$', '', name).strip()
            is_series = (
                is_series_page or
                'staffel' in name.lower() or
                '/serienstream' in href
            )
            items.append({
                'title': name_clean,
                'year': entry_year,
                'url': href,
                'mediatype': 'tvshow' if is_series else 'movie',
            })

        if not items:
            for block in html.split('<div class="short">')[1:]:
                link_m = re.search(
                    r'class=["\']begin["\'][^>]*>.*?'
                    r'<a href="(https?://[^"]+\.html)"[^>]*>([^<]+)</a>',
                    block, re.S | re.I
                )
                if not link_m:
                    continue
                href = self._abs(link_m.group(1))
                name = link_m.group(2).strip()
                year_m = re.search(r'\((\d{4})\)\s*$', name)
                entry_year = year_m.group(1) if year_m else ''
                name_clean = re.sub(r'\s*\(\d{4}\)\s*$', '', name).strip()
                is_series = (
                    is_series_page or
                    bool(re.search(
                        r'text-align:right[^>]*>(?:<[^>]+>)*\s*S\d{1,2}',
                        block[:1000], re.I
                    ))
                )
                items.append({
                    'title': name_clean,
                    'year': entry_year,
                    'url': href,
                    'mediatype': 'tvshow' if is_series else 'movie',
                })
        return items

    def _search(self, title, is_series=False):
        encoded = quote(str(title))
        urls = [
            self.base_link + '?do=search&subaction=search&titleonly=3'
            '&story=%s&x=0&y=0&submit=submit' % encoded,
            self.base_link + '/?do=search&subaction=search&titleonly=3'
            '&story=%s&x=0&y=0&submit=submit' % encoded,
        ]
        for url in urls:
            html = self._get(url)
            if not html:
                continue
            rows = self._parse_entries(html, is_series_page=is_series)
            if rows:
                return rows
        return []

    def _streams_datalinks(self, html):
        labels = re.findall(r'title="Stream\.([^"]+)"', html)
        raw_urls = re.findall(r'data-link="([^"]+)"', html)
        result = []
        for i, raw in enumerate(raw_urls):
            raw = raw.strip()
            if not raw or raw.startswith('/vod/'):
                continue
            raw = self._abs(raw)
            if 'meinecloud' in raw.lower():
                continue
            host = urlparse(raw).hostname or SITE_NAME
            if 'supervideo' in host.lower():
                continue
            q = self._quality(labels[i]) if i < len(labels) else 'HD'
            result.append((host, raw, q))
        return result

    def _streams_js(self, html, season=0, episode=0):
        links = re.findall(r'\.show\(.+?,(\[\[.+?\]\])', html)
        labels = re.findall(r'title="Stream\.([^"]+)"', html)
        if not links:
            return []

        s = max(0, int(season or 1) - 1)
        e = max(0, int(episode or 1) - 1)
        result = []

        for i, link_data in enumerate(links):
            try:
                pw = ast.literal_eval(link_data)
                raw = str(pw[s][e]).strip()
            except Exception:
                continue
            raw = self._abs(raw)
            if not raw:
                continue
            host = urlparse(raw).hostname or SITE_NAME
            if 'supervideo' in host.lower():
                continue
            q = self._quality(labels[i]) if i < len(labels) else 'HD'
            result.append((host, raw, q))
        return result

    def _streams(self, html, season=0, episode=0):
        rows = self._streams_datalinks(html)
        return rows if rows else self._streams_js(html, season, episode)

    def _append(self, host, raw, quality):
        low = raw.split('?', 1)[0].lower()
        direct = low.endswith(('.m3u8', '.mp4', '.mpd'))

        if direct:
            url = raw
            prio = 100
            source_name = host
        else:
            blocked, resolved_host, url, prio = isBlockedHoster(
                raw, isResolve=False
            )
            if blocked:
                return
            source_name = host or resolved_host

        self.sources.append({
            'source': source_name or SITE_NAME,
            'quality': quality or 'HD',
            'language': 'de',
            'url': url,
            'direct': direct,
            'priority': self.priority,
            'prioHoster': prio,
        })

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        years = {
            str(year),
            str(int(year) + 1) if year else '',
            str(int(year) - 1) if year else '',
        }

        match_url = ''
        for title in titles:
            if not title:
                continue
            target = self._clean(title)
            for entry in self._search(title, is_series=bool(season)):
                eclean = self._clean(
                    re.sub(
                        r'\s+(Film|Stream|Serie|Staffel\s*\d+)\s*$',
                        '', entry.get('title', ''), flags=re.I
                    )
                )
                if target not in eclean and eclean not in target:
                    continue
                entry_year = str(entry.get('year') or '')
                if year and not season and entry_year and entry_year not in years:
                    continue
                if season and entry.get('mediatype') != 'tvshow':
                    continue
                match_url = entry.get('url') or ''
                break
            if match_url:
                break

        if not match_url:
            return self.sources

        html = self._get(match_url)
        for host, raw, quality in self._streams(
            html, int(season or 1), int(episode or 1)
        ):
            self._append(host, raw, quality)

        return self.sources

    def resolve(self, url):
        return url
