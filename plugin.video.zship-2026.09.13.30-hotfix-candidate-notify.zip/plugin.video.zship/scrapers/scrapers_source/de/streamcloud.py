# -*- coding: utf-8 -*-
# StreamCloud current zShip provider
# Ported from the supplied working xStream scraper, adapted to zShip's source API.
# 2026-09-12.16

import base64
import html
import re
import unicodedata
from urllib.parse import quote_plus, unquote, urljoin, urlparse

from resources.lib.control import getSetting
from resources.lib.requestHandler import cRequestHandler
from resources.lib.utils import isBlockedHoster
from resources.lib import log_utils

SITE_IDENTIFIER = 'streamcloud'
# Keep the xStream entry domain as the shipped fallback. zShip's startup domain
# resolver follows the redirect and persists the current final hostname.
SITE_DOMAIN = 'streamcloud.study'
SITE_NAME = 'STREAMCLOUD'


class source:
    def __init__(self):
        self.priority = int(getSetting(
            'provider.' + SITE_IDENTIFIER + '.priority', 100
        ))
        self.language = ['de']
        self.domain = getSetting(
            'provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN
        ) or SITE_DOMAIN
        self.base_link = 'https://' + self.domain
        self.search_link = (
            self.base_link + '/index.php?story=%s&do=search&subaction=search'
        )
        self.sources = []

    def _get(self, url, caching=True, referer=None):
        try:
            req = cRequestHandler(url, caching=caching, ignoreErrors=True)
            req.addHeaderEntry('Referer', referer or (self.base_link + '/'))
            req.cacheTime = 60 * 60 * 6
            return req.request() or ''
        except Exception as exc:
            log_utils.log(
                '[STREAMCLOUD] Request fehlgeschlagen: %s | %s'
                % (url, str(exc)),
                log_utils.LOGWARNING
            )
            return ''

    @staticmethod
    def _clean(value):
        value = html.unescape(str(value or '')).lower()
        value = unicodedata.normalize('NFKD', value)
        value = ''.join(
            ch for ch in value if not unicodedata.combining(ch)
        )
        value = value.replace('ß', 'ss')
        value = re.sub(r'\s*\((?:19|20)\d{2}\)\s*$', '', value)
        return re.sub(r'[^a-z0-9]', '', value)

    @staticmethod
    def _quality(value):
        text = str(value or '').upper()
        if '2160' in text or '4K' in text:
            return '4K'
        if '1440' in text or '2K' in text:
            return '1440p'
        if '1080' in text:
            return '1080p'
        if '720' in text or text == 'HD':
            return '720p'
        if '480' in text:
            return '480p'
        if '360' in text:
            return '360p'
        return 'HD'

    def _abs(self, value, base=None):
        value = html.unescape(str(value or '')).strip()
        if not value:
            return ''
        if value.startswith('//'):
            return 'https:' + value
        return urljoin(base or (self.base_link + '/'), value)

    def _search_rows(self, page):
        """Current StreamCloud search result structure used by xStream."""
        rows = []
        seen = set()

        patterns = (
            # Exact pattern used by the supplied xStream scraper.
            r'class=["\']thumb["\'].*?title=["\']([^"\']+).*?'
            r'href=["\']([^"\']+).*?_year["\'][^>]*>([^<]+)',
            # Slightly looser fallback for harmless attribute-order changes.
            r'<a\b[^>]*title=["\']([^"\']+)["\'][^>]*'
            r'href=["\']([^"\']+)["\'][^>]*>.*?'
            r'class=["\'][^"\']*_year[^"\']*["\'][^>]*>([^<]+)',
        )
        for pattern in patterns:
            for m in re.finditer(pattern, page, re.I | re.S):
                title = html.unescape(m.group(1)).strip()
                url = self._abs(m.group(2))
                year = re.sub(r'[^0-9]', '', m.group(3) or '')[:4]
                key = (title, url, year)
                if url and key not in seen:
                    seen.add(key)
                    rows.append(key)
            if rows:
                break
        return rows

    def _candidate_score(self, row_title, row_year, titles, year):
        cleaned = self._clean(row_title)
        title_clean = [self._clean(t) for t in (titles or []) if t]
        title_clean = [t for t in title_clean if t]
        if not title_clean:
            return -1

        if cleaned in title_clean:
            score = 100
        elif any(cleaned and (cleaned in t or t in cleaned) for t in title_clean):
            score = 70
        else:
            return -1

        if year and row_year:
            try:
                delta = abs(int(row_year) - int(year))
                if delta == 0:
                    score += 20
                elif delta == 1:
                    score += 5
                else:
                    score -= 40
            except Exception:
                pass
        return score

    def _find_page(self, titles, year, imdb='', season=0):
        """Search title first, then IMDb; scan a few result pages like xStream."""
        queries = [str(t) for t in (titles or []) if t]
        if imdb:
            queries.append(str(imdb))

        best = None
        best_score = -1
        visited = set()

        for query in queries:
            if not query:
                continue
            base = self.search_link % quote_plus(query)
            page_urls = [base]
            sep = '&' if '?' in base else '?'
            # xStream searches follow-up pages because exact hits are sometimes
            # not on page 1. Keep zShip bounded to five pages.
            page_urls.extend(
                '%s%ssearch_start=%d' % (base, sep, page_no)
                for page_no in range(2, 6)
            )

            for page_url in page_urls:
                if page_url in visited:
                    continue
                visited.add(page_url)
                page = self._get(page_url, caching=False)
                if not page:
                    continue
                rows = self._search_rows(page)
                if not rows:
                    # A reached empty follow-up page is the natural end.
                    if page_url != base:
                        break
                    continue

                for row_title, row_url, row_year in rows:
                    score = self._candidate_score(
                        row_title, row_year, titles, year
                    )
                    # IMDb searches can return the exact title even when titles
                    # contain punctuation/alternate names.
                    if score < 0 and imdb and query == str(imdb):
                        score = 50
                    if score > best_score:
                        best_score = score
                        best = (row_url, row_title, row_year)

                if best_score >= 120:
                    break
            if best_score >= 120:
                break

        if not best:
            return '', ''

        page_url = best[0]
        detail = self._get(page_url, caching=False)
        if detail:
            log_utils.log(
                '[STREAMCLOUD] Detailseite gefunden: %s' % page_url,
                log_utils.LOGINFO
            )
        return page_url, detail

    def _resolve_player_wrapper(self, wrapper_url, referer):
        """Resolve StreamCloud-internal /player/... wrappers to hoster URLs."""
        page = self._get(wrapper_url, caching=False, referer=referer)
        if not page:
            return []
        found = []
        for pattern in (
            r'<iframe[^>]+src=["\']([^"\']+)["\']',
            r'data-link=["\']([^"\']+)["\']',
        ):
            for raw in re.findall(pattern, page, re.I):
                full = self._abs(raw, wrapper_url)
                if full and full not in found:
                    found.append(full)
        return found

    @staticmethod
    def _decode_meinecloud_wrapper(raw_url):
        """Decode MeineCloud's base64 wrapper path without requesting it."""
        try:
            parsed = urlparse(str(raw_url or ''))
            host = (parsed.hostname or '').lower()
            if 'meinecloud' not in host:
                return ''

            parts = [part for part in parsed.path.split('/') if part]
            if len(parts) < 2:
                return ''

            kind = parts[-2].lower()
            token = unquote(parts[-1]).strip()
            if kind not in ('movie', 'ddl', 'serial') or not token:
                return ''

            # Real IMDb/numeric lookup endpoints are not encoded wrappers.
            if re.match(r'^(?:tt)?\d{5,12}$', token, re.I):
                return ''

            padded = token + ('=' * ((4 - len(token) % 4) % 4))
            decoded = base64.urlsafe_b64decode(
                padded.encode('ascii')
            ).decode('utf-8', 'strict').strip()

            if decoded.startswith('//'):
                decoded = 'https:' + decoded
            elif decoded.startswith('/'):
                decoded = 'https:' + decoded
            elif not decoded.lower().startswith(('http://', 'https://')):
                return ''

            target = urlparse(decoded)
            if not target.hostname:
                return ''
            return decoded
        except Exception:
            return ''

    def _expand_meinecloud(self, raw_url, referer):
        """Expand one MeineCloud wrapper level to the actual hoster list."""
        raw_url = self._abs(raw_url, referer)
        host = (urlparse(raw_url).hostname or '').lower()
        if 'meinecloud' not in host:
            return [raw_url]

        # Current MeineCloud wrapper URLs are often just base64-encoded hoster
        # URLs. Decode them locally first so Cloudflare on the wrapper endpoint
        # cannot discard an otherwise valid source.
        decoded = self._decode_meinecloud_wrapper(raw_url)
        if decoded:
            log_utils.log(
                '[STREAMCLOUD] MeineCloud-Wrapper lokal decodiert -> %s'
                % ((urlparse(decoded).hostname or 'hoster')),
                log_utils.LOGINFO
            )
            return [decoded]

        # Lookup endpoints such as /movie/tt... or /serial/... still need the
        # page request because they contain the wrapper list.
        page = self._get(raw_url, caching=False, referer=referer)
        if not page:
            return []

        found = []
        patterns = (
            r'data-link=["\']([^"\']+)["\']',
            r'<iframe[^>]+src=["\']([^"\']+)["\']',
            r"window\.open.*?[\"'](https?://[^\"']+)[\"']",
        )
        for pattern in patterns:
            for value in re.findall(pattern, page, re.I | re.S):
                full = self._abs(value, raw_url)
                if not full:
                    continue

                decoded_child = self._decode_meinecloud_wrapper(full)
                if decoded_child:
                    full = decoded_child

                target_host = (urlparse(full).hostname or '').lower()
                if target_host and 'meinecloud' in target_host and full == raw_url:
                    continue
                if full not in found:
                    found.append(full)
        return found

    def _native_episode_links(self, page_url, page, season, episode):
        episode_id = '%sx%s' % (int(season), int(episode))
        # Same logical block isolation as the supplied xStream scraper:
        # one <li> containing data-num="SxE", including all mirror data-links.
        block_pattern = (
            r'<li>\s*<a\b[^>]*data-num=["\']%s["\'].*?</li>'
            % re.escape(episode_id)
        )
        m = re.search(block_pattern, page, re.I | re.S)
        if not m:
            return []
        block = m.group(0)
        # Real HTML comments are disabled mirrors; preserve <!--- ... ---> style.
        block = re.sub(
            r'<!--(?!-)(.*?)(?<!-)-->', '', block,
            flags=re.I | re.S
        )

        result = []
        for raw in re.findall(r'data-link=["\']([^"\']+)["\']', block, re.I):
            if raw.startswith('/'):
                wrapper = self._abs(raw, page_url)
                for resolved in self._resolve_player_wrapper(wrapper, page_url):
                    if resolved not in result:
                        result.append(resolved)
            else:
                full = self._abs(raw, page_url)
                if full and full not in result:
                    result.append(full)
        return result

    def _native_movie_links(self, page_url, page):
        result = []

        # Direct data-links on the detail page.
        for raw in re.findall(r'data-link=["\']([^"\']+)["\']', page, re.I):
            full = self._abs(raw, page_url)
            if full and full not in result:
                result.append(full)

        # xStream isolates an iframe TAG containing allowfull/allowfullscreen,
        # then reads src from that tag. Attribute order must not matter.
        iframe_tags = re.findall(
            r'<iframe\b[^>]*allowfull[^>]*>',
            page, re.I | re.S
        )
        for tag in iframe_tags:
            src_match = re.search(
                r'\bsrc\s*=\s*["\']([^"\']+)["\']',
                tag, re.I
            )
            if not src_match:
                continue

            iframe_url = self._abs(src_match.group(1), page_url)
            if not iframe_url:
                continue

            log_utils.log(
                '[STREAMCLOUD] Movie-Player iframe: %s' % iframe_url,
                log_utils.LOGINFO
            )

            iframe_page = self._get(
                iframe_url, caching=False, referer=page_url
            )
            for link in re.findall(
                r'data-link=["\']([^"\']+)["\']', iframe_page, re.I
            ):
                full = self._abs(link, iframe_url)
                if full and full not in result:
                    result.append(full)

        return result

    def _serial_cloud_links(self, imdb, season, episode):
        if not imdb:
            return []
        imdb_num = re.sub(r'[^0-9]', '', str(imdb))
        if not imdb_num:
            return []

        pages = []
        for url in (
            'https://meinecloud.click/serial/%s' % imdb_num,
            'https://meinecloud.click/serial/%s' % imdb,
        ):
            page = self._get(url, caching=False, referer=self.base_link + '/')
            if page:
                pages.append((url, page))

        result = []
        target = 'S%s E%s' % (int(season), int(episode))
        # Preserve the old compact label parser first.
        label_pattern = (
            r'data-link=["\']([^"\']+)["\']\s+'
            r'data-label=["\']S%s\s*E%s(?:\b|[^0-9])'
            % (int(season), int(episode))
        )
        for page_url, page in pages:
            for raw in re.findall(label_pattern, page, re.I):
                full = self._abs(raw, page_url)
                if full and full not in result:
                    result.append(full)

            # Current MeineCloud serial markup can group links in a season block.
            if result:
                continue
            blocks = re.split(
                r'(?=<div[^>]*class=["\'][^"\']*_season-eps[^"\']*["\'])',
                page
            )
            for block in blocks:
                # Use explicit S/E label if present in the block.
                for raw, label in re.findall(
                    r'data-link=["\']([^"\']+)["\'][^>]*'
                    r'data-label=["\']([^"\']+)["\']',
                    block, re.I
                ):
                    normalized = re.sub(r'\s+', ' ', label).strip().upper()
                    if normalized.startswith(target.upper()):
                        full = self._abs(raw, page_url)
                        if full and full not in result:
                            result.append(full)
        return result

    def _movie_cloud_links(self, imdb):
        if not imdb:
            return []
        result = []
        for page_url in (
            'https://meinecloud.click/movie/%s' % imdb,
            'https://meinecloud.click/ddl/%s' % imdb,
        ):
            page = self._get(page_url, caching=False, referer=self.base_link + '/')
            if not page:
                continue
            for pattern in (
                r'data-link=["\']([^"\']+)["\']',
                r'href=["\'](https?://[^"\']+)["\']',
            ):
                for raw in re.findall(pattern, page, re.I):
                    full = self._abs(raw, page_url)
                    if full and full not in result:
                        result.append(full)
        return result

    def _append_links(self, links, referer):
        seen = {item.get('url') for item in self.sources}
        queue = []
        for raw in links:
            raw = self._abs(raw, referer)
            if not raw:
                continue
            host = (urlparse(raw).hostname or '').lower()
            if 'meinecloud' in host:
                expanded = self._expand_meinecloud(raw, referer)
                queue.extend(expanded)
            else:
                queue.append(raw)

        for raw in queue:
            raw = self._abs(raw, referer)
            if not raw or raw in seen:
                continue
            host = (urlparse(raw).hostname or '').lower()
            if not host:
                continue
            # Skip self/internal links; only actual hoster/media URLs belong in
            # the source list.
            if host.lstrip('www.') == self.domain.lower().lstrip('www.'):
                continue
            if 'meinecloud' in host:
                # Unexpanded wrappers are not useful to ResolveURL.
                continue
            if any(x in host for x in (
                'imdb.', 'themoviedb.', 'youtube.', 'facebook.',
                'instagram.', 'twitter.', 'google.'
            )):
                continue

            blocked, hoster, checked, prio = isBlockedHoster(
                raw, isResolve=False, provider=SITE_IDENTIFIER
            )
            if blocked:
                continue

            final_url = checked or raw
            low = final_url.split('?', 1)[0].lower()
            direct = low.endswith(('.m3u8', '.mp4', '.mpd'))
            self.sources.append({
                'source': hoster or host,
                'quality': self._quality(final_url),
                'language': 'de',
                'url': final_url,
                'direct': direct,
                'priority': self.priority,
                'prioHoster': prio,
            })
            seen.add(final_url)

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        season = int(season or 0)
        episode = int(episode or 0)

        try:
            page_url, page = self._find_page(
                titles, year, imdb=imdb, season=season
            )

            links = []
            if season > 0:
                if page:
                    links.extend(
                        self._native_episode_links(
                            page_url, page, season, episode
                        )
                    )
                # StreamCloud's current series path can be entirely MeineCloud-
                # backed. Use it as the structural fallback from the xStream port.
                if not links:
                    links.extend(
                        self._serial_cloud_links(imdb, season, episode)
                    )
            else:
                if page:
                    links.extend(self._native_movie_links(page_url, page))
                if not links:
                    links.extend(self._movie_cloud_links(imdb))

            log_utils.log(
                '[STREAMCLOUD] Rohlinks vor Hoster-Filter: %d' % len(links),
                log_utils.LOGINFO
            )
            self._append_links(
                links,
                page_url or (self.base_link + '/')
            )

            log_utils.log(
                '[STREAMCLOUD] Ergebnis: %d Quellen | mode=%s%s'
                % (
                    len(self.sources),
                    'episode' if season > 0 else 'movie',
                    (' | page=' + page_url) if page_url else ''
                ),
                log_utils.LOGINFO
            )
            return self.sources
        except Exception as exc:
            log_utils.log(
                '[STREAMCLOUD] Fehler: %s' % str(exc),
                log_utils.LOGWARNING
            )
            return self.sources

    def resolve(self, url):
        return url
