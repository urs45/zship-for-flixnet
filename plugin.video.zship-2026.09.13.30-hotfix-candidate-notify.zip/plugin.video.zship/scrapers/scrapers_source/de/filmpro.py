# -*- coding: utf-8 -*-
# FilmPro / MeineCloud bridge for zShip
# 2026-09-12.6

import re
import time
from urllib.parse import urlparse, quote, unquote

from resources.lib.requestHandler import cRequestHandler
from resources.lib.utils import isBlockedHoster
from resources.lib.control import getSetting
from resources.lib import log_utils

SITE_IDENTIFIER = 'filmpro'
SITE_DOMAIN = 'filmpalast.one'
SITE_NAME = 'FILMPRO'


class source:
    def __init__(self):
        self.priority = int(getSetting(
            'provider.' + SITE_IDENTIFIER + '.priority', 100
        ))
        self.language = ['de']
        self.domain = getSetting(
            'provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN
        ) or SITE_DOMAIN
        self.base_link = 'https://' + self.domain
        self.sources = []

    @staticmethod
    def _request(url, force=False):
        try:
            if force:
                url += ('&' if '?' in url else '?') + '_=%d' % int(time.time() * 1000)
            req = cRequestHandler(url, caching=not force, ignoreErrors=True)
            return req.request() or ''
        except Exception:
            return ''

    @staticmethod
    def _quality(text):
        t = str(text or '').upper()
        if '2160' in t or '4K' in t:
            return '4K'
        if '1080' in t:
            return '1080p'
        if '720' in t:
            return '720p'
        if '480' in t:
            return '480p'
        return 'HD'

    @staticmethod
    def _hostname(url):
        try:
            return (urlparse(url).hostname or '').lower()
        except Exception:
            return ''

    def _movie_links(self, imdb, force=False):
        result = []

        # MovieScout's FilmPro delegates movies to its cloud helper. zShip's
        # historical provider already exposed MeineCloud /ddl; combine /ddl
        # and /movie so the refreshed source pool is broader.
        ddl = self._request(
            'https://meinecloud.click/ddl/%s' % str(imdb), force=force
        )
        for link, quality in re.findall(
            r"window\.open.*?'([^']+).*?mark>([^<]+)",
            ddl, re.S | re.I
        ):
            if link:
                result.append((link.strip(), self._quality(quality)))

        movie = self._request(
            'https://meinecloud.click/movie/%s' % str(imdb), force=force
        )
        data_links = re.findall(r'data-link=["\']([^"\']+)["\']', movie, re.I)
        labels = re.findall(r'data-label=["\']([^"\']+)["\']', movie, re.I)
        for idx, link in enumerate(data_links):
            link = link.strip()
            if link.startswith('//'):
                link = 'https:' + link
            if not link or not link.startswith(('http://', 'https://')):
                continue
            label = labels[idx] if idx < len(labels) else ''
            result.append((link, self._quality(label)))

        out = []
        seen = set()
        for link, quality in result:
            if link in seen:
                continue
            seen.add(link)
            out.append((link, quality))
        return out

    def _episode_links(self, imdb, season, episode, force=False):
        imdb_num = re.sub(r'[^0-9]', '', str(imdb or ''))
        html = self._request(
            'https://meinecloud.click/serial/%s' % imdb_num, force=force
        )
        if not html:
            html = self._request(
                'https://meinecloud.click/serial/%s' % str(imdb),
                force=force
            )
        if not html:
            return []

        sid_to_snum = {}
        for sid, label in re.findall(
            r'data-season=["\'](\d+)["\'][^>]*>\s*(S\d+)\s*<',
            html, re.I
        ):
            m = re.match(r'S(\d+)', label.strip(), re.I)
            if m:
                sid_to_snum[sid] = int(m.group(1))

        blocks = re.split(
            r'(?=<div[^>]*class=["\'][^"\']*_season-eps[^"\']*["\'][^>]*data-season=["\'])',
            html
        )

        result = []
        for block in blocks:
            sid_m = re.match(
                r'<div[^>]*data-season=["\'](\d+)["\']', block, re.I
            )
            if not sid_m:
                continue
            snum = sid_to_snum.get(sid_m.group(1))
            if snum != int(season):
                continue

            links = re.findall(r'data-link=["\']([^"\']+)["\']', block, re.I)
            labels = re.findall(r'data-label=["\']([^"\']+)["\']', block, re.I)
            ep_nums = re.findall(
                r'<div[^>]*class=["\'][^"\']*_ep-n[^"\']*["\'][^>]*>(\d+)</div>',
                block, re.I
            )
            for i, link in enumerate(links):
                ep_num = int(ep_nums[i]) if i < len(ep_nums) else i + 1
                if ep_num != int(episode):
                    continue
                link = link.strip()
                if link.startswith('//'):
                    link = 'https:' + link
                if not link:
                    continue
                label = labels[i] if i < len(labels) else ''
                result.append((link, self._quality(label)))
        return result

    def _links(self, imdb, season=0, episode=0, force=False):
        if int(season or 0) > 0:
            return self._episode_links(imdb, season, episode, force=force)
        return self._movie_links(imdb, force=force)

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        if not imdb:
            return self.sources

        links = self._links(imdb, season, episode, force=False)
        seen_hosts = set()

        for raw_url, quality in links:
            host = self._hostname(raw_url)
            if not host or host in seen_hosts:
                continue

            blocked, hoster, checked, prio = isBlockedHoster(
                raw_url, isResolve=False
            )
            if blocked:
                continue

            seen_hosts.add(host)
            if int(season or 0) > 0:
                token = 'filmprorefresh://episode/%s/%s/%s?host=%s' % (
                    imdb, int(season), int(episode), quote(host, safe='')
                )
            else:
                token = 'filmprorefresh://movie/%s?host=%s' % (
                    imdb, quote(host, safe='')
                )

            self.sources.append({
                'source': hoster or host,
                'quality': quality,
                'language': 'de',
                'url': token,
                'direct': True,
                'priority': self.priority,
                'prioHoster': prio,
            })

        return self.sources

    def resolve(self, url):
        text = str(url or '')
        if not text.startswith('filmprorefresh://'):
            return text

        host_m = re.search(r'[?&]host=([^&]+)', text)
        wanted_host = unquote(host_m.group(1)) if host_m else ''

        season = 0
        episode = 0
        imdb = ''

        if text.startswith('filmprorefresh://episode/'):
            base = text.split('?', 1)[0]
            parts = base[len('filmprorefresh://episode/'):].split('/')
            if len(parts) >= 3:
                imdb, season, episode = parts[0], int(parts[1]), int(parts[2])
        else:
            base = text.split('?', 1)[0]
            imdb = base[len('filmprorefresh://movie/'):]

        for attempt in (1, 2):
            links = self._links(
                imdb, season, episode, force=True
            )

            ordered = []
            for link, quality in links:
                if self._hostname(link) == wanted_host:
                    ordered.insert(0, (link, quality))
                else:
                    ordered.append((link, quality))

            # Keep the selected host first. On the second attempt we also allow
            # another freshly returned host so FilmPro can survive a dead mirror.
            candidates = ordered if attempt == 2 else [
                x for x in ordered if self._hostname(x[0]) == wanted_host
            ]

            for raw_url, quality in candidates:
                low = raw_url.split('?', 1)[0].lower()
                if low.endswith(('.m3u8', '.mp4', '.mpd')):
                    return raw_url

                blocked, hoster, resolved, prio = isBlockedHoster(
                    raw_url, isResolve=True
                )
                if not blocked and resolved:
                    return resolved

            time.sleep(0.35)

        log_utils.log(
            '[FILMPRO] Kein frischer spielbarer Mirror fuer %s'
            % (wanted_host or imdb),
            log_utils.LOGWARNING
        )
        return None
