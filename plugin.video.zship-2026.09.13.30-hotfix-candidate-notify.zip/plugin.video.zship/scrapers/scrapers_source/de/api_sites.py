# -*- coding: utf-8 -*-
# zShip API-SEITEN provider
# 2026-09-12.4
#
# Deliberately cheap side-check:
# - one configured mirror only
# - one keyword request per distinct title alias (max 2)
# - no mirror cascade
# - no full-catalog fallback

import json
import re
from random import randint
from urllib.parse import urlparse

from resources.lib.control import getSetting, quote_plus
from resources.lib.requestHandler import cRequestHandler
from resources.lib.utils import getHostDict
from resources.lib import log_utils
from scrapers.modules import cleantitle

SITE_IDENTIFIER = "api_sites"
SITE_DOMAIN = "megakino.to"
SITE_NAME = "API-SEITEN"


def _normalize_domain(value):
    raw = str(value or "").strip()
    if not raw:
        raw = SITE_DOMAIN
    if "://" not in raw:
        raw = "https://" + raw
    try:
        parsed = urlparse(raw)
        host = (parsed.netloc or parsed.path).strip().strip("/")
    except Exception:
        host = raw
    host = re.sub(r"^https?://", "", host, flags=re.I)
    host = host.split("/")[0].strip().strip("/")
    return host or SITE_DOMAIN


def _clean(value):
    text = str(value or "").strip()
    text = re.sub(r"\s*[\(\[\{]\s*(?:19|20)\d{2}\s*[\)\]\}]\s*$", "", text)
    text = re.sub(r"\s*[-–—]\s*(?:19|20)\d{2}\s*$", "", text)
    return cleantitle.get(text)


class source:
    def __init__(self):
        self.priority = int(getSetting("provider.%s.priority" % SITE_IDENTIFIER, 100))
        self.language = ["de"]
        self.domain = _normalize_domain(
            getSetting("provider.%s.domain" % SITE_IDENTIFIER, SITE_DOMAIN)
        )
        self.base_link = "https://" + self.domain
        self.sources = []

    def _request_json(self, path, cache_time=None, force=False):
        url = self.base_link + path
        if force:
            url += ("&" if "?" in url else "?") + "_=%s" % randint(
                100000000, 999999999
            )

        req = cRequestHandler(url, caching=not force, ignoreErrors=True)
        if cache_time is not None and not force:
            req.cacheTime = int(cache_time)
        req.addHeaderEntry("Referer", self.base_link + "/")
        req.addHeaderEntry("Origin", self.base_link + "/")

        try:
            raw = req.request()
            if raw:
                data = json.loads(raw)
                if isinstance(data, dict):
                    return data
        except Exception as exc:
            log_utils.log(
                "API-SEITEN JSON Fehler: %s | %s" % (url, str(exc)),
                log_utils.LOGWARNING,
            )
        return None

    @staticmethod
    def _season_from_title(title):
        text = str(title or "")
        for pattern in (
            r"(?i)\b(?:staffel|season)\s*0*(\d+)\b",
            r"(?i)\b0*(\d+)\s*(?:staffel|season)\b",
            r"(?i)\bS0*(\d+)\b",
        ):
            m = re.search(pattern, text)
            if m:
                try:
                    return int(m.group(1))
                except Exception:
                    pass
        return None

    @staticmethod
    def _series_base_title(title):
        text = str(title or "").strip()
        for pattern in (
            r"(?i)\s*[-–—:]\s*(?:staffel|season)\s*0*\d+\b.*$",
            r"(?i)\s*[-–—:]\s*0*\d+\s*(?:staffel|season)\b.*$",
            r"(?i)\s*[-–—:]\s*S0*\d+\b.*$",
        ):
            new = re.sub(pattern, "", text).strip()
            if new != text:
                return new
        return re.sub(
            r"(?i)\s+(?:(?:staffel|season)\s*0*\d+|0*\d+\s*(?:staffel|season))\s*$",
            "",
            text,
        ).strip()

    @staticmethod
    def _quality(release, fallback="HD"):
        text = str(release or "").upper()
        if "2160" in text or "4K" in text or "UHD" in text:
            return "4K"
        if "1440" in text:
            return "1440p"
        if "1080" in text:
            return "1080p"
        if "720" in text:
            return "720p"
        if "HDCAM" in text or re.search(r"\b(?:CAM|TS)\b", text):
            return "CAM"
        if re.search(r"\b(?:HD|WEB|BLUERAY|BLU-RAY|BRRIP)\b", text):
            return "HD"
        return fallback or "HD"

    @staticmethod
    def _explicit_english(release):
        text = str(release or "").lower()
        return (
            ("english" in text or "englisch" in text)
            and "german" not in text
            and "deutsch" not in text
        )

    @staticmethod
    def _blocked_by_user(url):
        try:
            host = (urlparse(url).hostname or "").lower()
            for blocked in getHostDict():
                blocked = str(blocked or "").lower().strip()
                if blocked and (host == blocked or host.endswith("." + blocked)):
                    return True
        except Exception:
            pass
        return False

    def _candidate_matches(self, movie, wanted, year, season):
        if not isinstance(movie, dict) or not movie.get("_id"):
            return False

        title = str(movie.get("title") or "")
        if not title:
            return False

        if int(season or 0) > 0:
            if self._season_from_title(title) != int(season):
                return False
            base = _clean(self._series_base_title(title))
            return base == wanted

        if _clean(title) != wanted:
            return False

        # Keep identity conservative. Unknown years are accepted, but a
        # clearly different known year is not. API-SEITEN is only a side-check.
        item_year = movie.get("year")
        try:
            if year and item_year not in (None, ""):
                return abs(int(item_year) - int(year)) <= 1
        except Exception:
            pass
        return True

    def _search(self, titles, year, season):
        media_type = "tvseries" if int(season or 0) > 0 else "movies"

        aliases = []
        for title in titles or []:
            title = str(title or "").strip()
            if title and _clean(title) and _clean(title) not in [_clean(x) for x in aliases]:
                aliases.append(title)
            if len(aliases) >= 2:
                break

        for title in aliases:
            wanted = _clean(title)
            path = (
                "/data/browse/?lang=2&type=%s&order_by=new&keyword=%s&page=1"
                % (media_type, quote_plus(title))
            )
            data = self._request_json(path, cache_time=60 * 60 * 6)
            rows = data.get("movies", []) if isinstance(data, dict) else []
            if not isinstance(rows, list):
                rows = []

            matches = [
                row for row in rows
                if self._candidate_matches(row, wanted, year, season)
            ]

            sample = " | ".join(
                str(row.get("title") or "") for row in rows[:3]
                if isinstance(row, dict)
            )
            log_utils.log(
                "API-SEITEN Kurzcheck: mirror=%s title=%s raw=%d match=%d sample=%s"
                % (self.domain, title, len(rows), len(matches), sample),
                log_utils.LOGINFO,
            )

            if matches:
                return matches

        return []

    def run(self, titles, year, season=0, episode=0, imdb="", hostDict=None):
        self.sources = []

        entries = self._search(titles, year, season)
        if not entries:
            return self.sources

        seen = set()

        for entry in entries[:2]:
            data = self._request_json(
                "/data/watch/?_id=%s" % str(entry["_id"]),
                cache_time=60 * 60 * (4 if int(season or 0) > 0 else 6),
            )
            streams = data.get("streams", []) if isinstance(data, dict) else []
            if not isinstance(streams, list):
                continue

            for stream in streams:
                if not isinstance(stream, dict):
                    continue

                # Original xStream api_sites filters episodes only for series.
                # Movie stream rows are not discarded merely because an "e"
                # field happens to exist.
                if int(season or 0) > 0:
                    try:
                        if int(stream.get("e")) != int(episode):
                            continue
                    except Exception:
                        continue

                url = str(stream.get("stream") or "").strip()
                if not url or not url.startswith(("http://", "https://")):
                    continue
                if url in seen or self._blocked_by_user(url):
                    continue

                release = str(stream.get("release") or "")
                if self._explicit_english(release):
                    continue

                host = urlparse(url).hostname or "API"
                path_l = urlparse(url).path.lower()
                direct = path_l.endswith((".m3u8", ".mp4", ".mpd"))

                seen.add(url)
                self.sources.append(
                    {
                        "source": host,
                        "quality": self._quality(
                            release,
                            str(entry.get("quality") or "HD"),
                        ),
                        "language": "de",
                        "url": url,
                        "direct": direct,
                        "priority": self.priority,
                        "prioHoster": 100,
                        "info": release,
                    }
                )

        log_utils.log(
            "API-SEITEN Kurzcheck Quellen: %d | mirror=%s"
            % (len(self.sources), self.domain),
            log_utils.LOGINFO,
        )
        return self.sources

    def resolve(self, url):
        return url
